/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects;

/**
 *
 * @author freon
 */
public class Charsets {
    private String inputCharset;
    private String outputCharset;

    public Charsets(String inputCharset, String outputCharset) {
        this.inputCharset = inputCharset;
        this.outputCharset = outputCharset;
    }

    public String getInputCharset() {
        return inputCharset;
    }

    public void setInputCharset(String inputCharset) {
        this.inputCharset = inputCharset;
    }

    public String getOutputCharset() {
        return outputCharset;
    }

    public void setOutputCharset(String outputCharset) {
        this.outputCharset = outputCharset;
    }

}
