/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor;

import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PathSettings;
import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Config;
import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Ignore;
import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Meta;
import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Meta.Matches;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppConstants;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppUtils;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.PreprocessorUtils;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.Charsets;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.InputLines;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PartOfText;
import edu.mit.csail.brill.BrillTagger;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.jdesktop.application.Task;

/**
 *
 * @author freon
 */
public class Preprocessor {

    private File inputFile;
    private File outputFile;
    private Config config;
    private Charsets charsets;
    private InputLines inputLines;
    private List<PartOfText> partsOfText;
    private boolean newLineSentenceDelimiter = false;
    private int taggerType;
    private volatile boolean afterProcess = false;

    public Preprocessor(PathSettings settings, Charsets charsets) {
        this.inputFile = new File(settings.getInputFilePath());
        this.outputFile = new File(settings.getOutputFilePath());
        this.config = ConfigManager.loadXML(new File(settings.getConfigFilePath()));
        this.charsets = charsets;

    }

    private void readInput() {
        BufferedReader br = null;
        inputLines = new InputLines();
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), charsets.getInputCharset()));
            String line;
            while ((line = br.readLine()) != null) {
                inputLines.addLine(line);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, "Unable to open input file.", ex);
        } catch (IOException ex) {
            Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, "Unable to read from input.", ex);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private void filterInput() {
        Ignore ignore = config.getInput().getIgnore();
        int firstXLines = ignore.getFirstXLines().intValue();
        int lastXLines = ignore.getLastXLines().intValue();
        List<String> stopList = new ArrayList<String>();
        // TODO: stop list muze byt i file => rozlisit
        if (ignore.getStopList() != null) {
            if (ignore.getStopList().getWord() != null && ignore.getStopList().getWord().getValue() != null && ignore.getStopList().getWord().getValue().size() > 0) {
                stopList.addAll(ignore.getStopList().getWord().getValue());
            }
            if (ignore.getStopList().getFile() != null) {
                stopList.addAll(PreprocessorUtils.getList(ignore.getStopList().getFile().trim()));
            }
        }
        List<String> startWith = ignore.getLinesStartWith().getLineStartWith();
        List<Ignore.ValuesBetween.ValueBetween> valuesBetween = ignore.getValuesBetween().getValueBetween();
        List<String> SGMLTags = ignore.getSGMLTags().getTag();
        List<String> starts = new ArrayList<String>();
        List<String> ends = new ArrayList<String>();
        if (valuesBetween != null && valuesBetween.size() != 0) {
            for (int i = 0; i < valuesBetween.size(); i++) {
                String initiator = ((Ignore.ValuesBetween.ValueBetween) valuesBetween.get(i)).getInitiator().trim();
                String terminator = ((Ignore.ValuesBetween.ValueBetween) valuesBetween.get(i)).getTerminator().trim();
                if (initiator != null && !"".equals(initiator)) {
                    starts.add(initiator);
                }
                if (terminator != null && !"".equals(terminator)) {
                    ends.add(terminator);
                }
            }
        }
        if (SGMLTags != null && SGMLTags.size() != 0) {
            for (int i = 0; i < SGMLTags.size(); i++) {
                starts.add("<" + SGMLTags.get(i).trim() + ">");
                ends.add("</" + SGMLTags.get(i).trim() + ">");
            }
        }

        if (firstXLines > 0) {
            inputLines.removeXFirstLines(firstXLines);
        }
        if (lastXLines > 0) {
            inputLines.removeXLastLines(lastXLines);
        }
        if (startWith != null && startWith.size() > 0) {
            for (int i = 0; i < startWith.size(); i++) {
                String start = startWith.get(i).trim();
                if (!"".equals(start)) {
                    inputLines.removeLinesStartWith(start);
                }
            }
        }
        if (stopList != null && stopList.size() > 0) {
            inputLines.removeStopList(stopList);
        }
        if (starts.size() > 0 && ends.size() > 0) {
            for (int i = 0; i < starts.size() || i < ends.size(); i++) {
                inputLines.removeBetween(starts.get(i), ends.get(i));
            }
        }
        inputLines.removeBlankLines();
    }

    private void writeOutput(String text) {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile), charsets.getOutputCharset()));
//            BufferedReader br = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(text.getBytes(charsets.getOutputCharset()))));
//            for (int i = 0; i < inputLines.getLines().size(); i++) {
//                bw.write(br.readLine());
//                bw.newLine();
//            }
            bw.write(text);
        } catch (IOException ex) {
            Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (bw != null) {
                try {
                    bw.flush();
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public Task process(org.jdesktop.application.Application app) {
        readInput();
        filterInput();
        prepareTransformation();
        transformInputToPartsOfText();
        removeEmptyParts();
        PreprocessorUtils.concatLines(partsOfText, newLineSentenceDelimiter);
        return tagParts(app);
    }

    public void makePredicates() {
        if (afterProcess) {
            System.out.println(partsOfText);
            PredicateManager mgr = new PredicateManager(config.getOutput(), taggerType);
            String output = mgr.make(partsOfText);
            System.out.println("\n\n\n\noutput:\n*********\n" + output);
            writeOutput(output);
        }
    }

    private void prepareTransformation() {
        this.partsOfText = new LinkedList<PartOfText>();
        this.partsOfText.add(new PartOfText(inputLines.getLines()));
    }

    private void removeEmptyParts() {
        Iterator it = partsOfText.iterator();
        while (it.hasNext()) {
            PartOfText pot = (PartOfText) it.next();
            if (pot.getTextLines().size() == 0) {
                it.remove();
            }
        }
    }

    private void transformInputBySGMLTag(List<String> tag, String key, String type, boolean regexp) {
        boolean numType = "number".equals(type.trim());
        List<PartOfText> newParts = new ArrayList<PartOfText>(partsOfText.size());
        String lastMetaValue = AppConstants.UNKNOWN_STRING_VALUE;
        int lastIntMetaValue = AppConstants.UNKNOWN_NUMBER_VALUE;
        int lastSID = 0;

        for (PartOfText pot : partsOfText) {
            List list = new LinkedList<String>();
            PartOfText newPart = (numType ? new PartOfText(key, lastIntMetaValue, list) : new PartOfText(key, lastMetaValue, list));
            newParts.add(newPart);
            newPart.copyAttribs(pot);
            newPart.setSidOfFirstSentence(lastSID+1);
            if (numType) {
                newPart.addNumberAttr(key, lastIntMetaValue);
            } else {
                newPart.addStringAttr(key, lastMetaValue);
            }
            Iterator it = pot.getTextLines().iterator();
            while (it.hasNext()) {
                String line = ((String) it.next()).trim();
                boolean found = false;
                boolean foundBad = false;

                for (String st : tag) {
                    if ((foundBad = line.matches(".*</" + st.trim() + ">.*"))) {
                        break;
                    }
                    st = "<" + st.trim() + ">";
                    boolean cond = regexp ? PreprocessorUtils.match(st, line) : line.matches(".*" + st + ".*");
                    if (cond) {
                        found = true;
                        if (regexp) {
                            lastMetaValue = PreprocessorUtils.processRegex(st, line);
                        } else {
                            lastMetaValue = st.substring(1, st.length() - 1);
                        }
                        if (numType) {
                            try {
                                lastIntMetaValue = Integer.parseInt(lastMetaValue);
                            } catch (NumberFormatException nfe) {
                                Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, "Unable to convert '" + lastMetaValue + "' to a number.", nfe);
                            }
                            if (AppConstants.UNKNOWN_NUMBER_VALUE == newPart.getNumberAttributes().get(key)) {
                                newPart.getNumberAttributes().put(key, lastIntMetaValue);
                            } else if (lastIntMetaValue != newPart.getNumberAttributes().get(key)) {
                                List newList = new LinkedList<String>();
                                newPart = new PartOfText(key, lastIntMetaValue, newList);
                                newPart.copyAttribs(pot);
                                newPart.addNumberAttr(key, lastIntMetaValue);
                                newPart.setSidOfFirstSentence(lastSID+1);
                                newParts.add(newPart);
                            }
                            String aux = null;
                            if (regexp) {
                                aux = PreprocessorUtils.restOfLine(st, line);
                            } else {
                                aux = line.substring(line.indexOf(st) + st.length(), line.length());
                            }
                            if (!"".equals(aux.trim())) {
                                newPart.addLine(aux);
                            }
                            break;
                        } else { // string
                            if (AppConstants.UNKNOWN_STRING_VALUE.equals(newPart.getStringAttributes().get(key))) {
                                newPart.getStringAttributes().put(key, lastMetaValue);
                            } else if (!lastMetaValue.equals(newPart.getStringAttributes().get(key))) {
                                List newList = new LinkedList<String>();
                                newPart = new PartOfText(key, lastMetaValue, newList);
                                newPart.copyAttribs(pot);
                                newPart.addStringAttr(key, lastMetaValue);
                                newPart.setSidOfFirstSentence(lastSID+1);
                                newParts.add(newPart);
                            }
                            String aux = null;
                            if (regexp) {
                                aux = PreprocessorUtils.restOfLine(st, line);
                            } else {
                                aux = line.substring(line.indexOf(st) + st.length(), line.length());
                            }
                            if (!"".equals(aux.trim())) {
                                newPart.addLine(aux);
                            }
                            break;
                        }
                    }
                }
                if (!found && !foundBad) {
                    if (!"".equals(line.trim())) {
                        newPart.addLine(line);
                        lastSID++;
                    }
                }
            }
        }
        partsOfText = newParts;
    }

    private void transformInputByValuesStartWith(List<String> start, String key, String type) {
        List<PartOfText> newParts = new ArrayList<PartOfText>(partsOfText.size());
        String lastMetaValue = AppConstants.UNKNOWN_STRING_VALUE;
        int lastSID = 0;

        for (PartOfText pot : partsOfText) {
            List list = new LinkedList<String>();
            PartOfText newPart = new PartOfText(key, lastMetaValue, list);
            newParts.add(newPart);
            newPart.copyAttribs(pot);
            newPart.addStringAttr(key, lastMetaValue);
            newPart.setSidOfFirstSentence(lastSID);
            Iterator it = pot.getTextLines().iterator();
            while (it.hasNext()) {
                String line = ((String) it.next()).trim();
                boolean found = false;

                for (String st : start) {
                    st = st.trim();
                    if (line.startsWith(st)) { // 1st occurence
                        found = true;
                        lastMetaValue = st;
                        if (AppConstants.UNKNOWN_STRING_VALUE.equals(newPart.getStringAttributes().get(key))) {
                            newPart.getStringAttributes().put(key, st);
                        } else if (!st.equals(newPart.getStringAttributes().get(key))) {
                            List newList = new LinkedList<String>();
                            newPart = new PartOfText(key, st, newList);
                            newPart.copyAttribs(pot);
                            newPart.addStringAttr(key, st);
                            newPart.setSidOfFirstSentence(lastSID);
                            newParts.add(newPart);
                        }
                        String aux = line.substring(line.indexOf(st) + st.length(), line.length());
                        if (!"".equals(aux.trim())) {
                            newPart.addLine(aux);
                        }
                        break;
                    }
                }
                if (!found) {
                    if (!"".equals(line.trim())) {
                        lastSID++;
                        newPart.addLine(line);
                    }
                }
            }
        }
        partsOfText = newParts;
    }

    private void transformInputToPartsOfText() {
        if (config.getOutput().getSentenceDelimiters() != null) {
            this.newLineSentenceDelimiter = "newLine".equals(config.getOutput().getSentenceDelimiters());
        } else {
            this.newLineSentenceDelimiter = false;
        }

        List<Meta> metaTypes = config.getInput().getMetaTypes().getMetaType();
        if (metaTypes != null && metaTypes.size() > 0) {
            for (Meta metaType : metaTypes) {
                if (metaType.getMatches() == null) { // hard-coded meta type
                    PartOfText.addHardCodedAttribute(metaType.getKey().trim(), metaType.getValue().trim());
                } else {
                    Matches matches = metaType.getMatches();
                    if (matches.getSGMLTags() != null) {

                        if (matches.getSGMLTags().getFile() != null) { // file list is set
                            List<String> values = PreprocessorUtils.getList(matches.getSGMLTags().getFile().trim());
                            if (values != null && values.size() > 0) {
                                transformInputBySGMLTag(values, metaType.getKey(), metaType.getType(), false);
                            }
                        }
                        if (matches.getSGMLTags().getValues() != null && matches.getSGMLTags().getValues().getValue().size() > 0) {
                            boolean regExp = "true".equals(matches.getSGMLTags().getValues().getValue().get(0).getRegexp().trim());
                            List<String> tags = new ArrayList<String>();
                            for (int i = 0; i < matches.getSGMLTags().getValues().getValue().size(); i++) {
                                tags.add(matches.getSGMLTags().getValues().getValue().get(i).getValue());
                            }
                            transformInputBySGMLTag(tags, metaType.getKey(), metaType.getType(), regExp);
                        }
                    }
                    if (matches.getValuesStartWith() != null) {
                        if (matches.getValuesStartWith().getValueStartWith() != null && matches.getValuesStartWith().getValueStartWith().size() > 0) {
                            transformInputByValuesStartWith(matches.getValuesStartWith().getValueStartWith(), metaType.getKey(), metaType.getType());
                        }
                    }

                }
            }
        }

    }

    private Task tagParts(org.jdesktop.application.Application app) {
        if (!"none".equals(config.getInput().getTagger().value().trim())) {
            if ("brill".equals(config.getInput().getTagger().value().trim())) {
                taggerType = AppConstants.TAGGER_BRILL_ID;
                for (PartOfText pot : partsOfText) {
                    pot.setTaggedLines(pot.getTextLines());
                }
            } else if ("mbsp".equals(config.getInput().getTagger().value().trim())) {
                taggerType = AppConstants.TAGGER_MBSP_ID;
                for (PartOfText pot : partsOfText) {
                    pot.setTaggedText(pot.getText());
                }
            }
            return null; // there is already some tagging
        }
        if (config.getOutput() != null && config.getOutput().getTagger().value().trim() != null) {
            if ("brill".equals(config.getOutput().getTagger().value().trim())) {
                taggerType = AppConstants.TAGGER_BRILL_ID;
                BrillTagger bt = new BrillTagger();
                bt.setup();
                for (PartOfText pot : partsOfText) {
                    List<String> taggedLines = new LinkedList<String>();
                    for (String line : pot.getTextLines()) {
                        taggedLines.add(bt.tag(line).toString());
                    }
                    pot.setTaggedLines(taggedLines);
                }
                afterProcess = true;
                return null;
            } else if ("mbsp".equals(config.getOutput().getTagger().value().trim())) {
                taggerType = AppConstants.TAGGER_MBSP_ID;
                afterProcess = true;
                if (app == null) {
                    new MbspTask(null).doInBackground();
                    return null;
                }
                return new MbspTask(app);
            } else if ("tree".equals(config.getOutput().getTagger().value().trim())) {
                afterProcess = true;
                return null;
            } else {
                taggerType = AppConstants.TAGGER_NONE_ID;
                afterProcess = true;
                return null;
            }
        } else {
            afterProcess = true;
            return null;
        }
    }

    private class MbspTask extends org.jdesktop.application.Task<Object, Void> {

        private boolean cli;

        MbspTask(org.jdesktop.application.Application app) {
            // Runs on the EDT.  Copy GUI state that
            // doInBackground() depends on from parameters
            // to ChooseFileTask fields, here.
            super(app);
            this.cli = app == null;
        }

        @Override
        protected Object doInBackground() {
            long start = System.currentTimeMillis();

            Text2TaggedText t2tt = new Text2TaggedText();
            int i = 0;
            int all = partsOfText.size();
            for (PartOfText pot : partsOfText) {
                if (!AppUtils.isRunning()) {
                    break;
                }
                try {
                    setMessage(NumberFormat.getInstance().format((((double) ((double) i / partsOfText.size()))) * 100) + "%");
                    String tagged = t2tt.doConversion(pot.getText());
//                    System.out.println("tagged=  " + tagged);
                    if (tagged == null) {
                        if (cli) {
                            System.out.println("\n\nScript on " + AppConstants.SCRIPT_LOCATION + " is not responging.\n");
                        } else {
                            JOptionPane.showMessageDialog(null, "Script on " + AppConstants.SCRIPT_LOCATION + " is not responging.", "warning", JOptionPane.WARNING_MESSAGE);
                        }
                        return null;
                    }
                    pot.setTaggedText(tagged);
                    if (!cli) {
                        setProgress(i++, 0, all);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(Preprocessor.class.getName()).log(Level.SEVERE, "Unable to use remote mbsp tagger", ex);
                }

            }
            if (!cli) {
                setMessage("Elapsed time: " + (System.currentTimeMillis() - start) + " ms");
            }
            return null;  // return your result
        }

        @Override
        protected void succeeded(Object result) {
        }
    }
}


