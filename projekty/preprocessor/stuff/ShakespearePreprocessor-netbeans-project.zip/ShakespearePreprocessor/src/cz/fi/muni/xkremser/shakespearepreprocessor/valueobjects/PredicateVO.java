/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects;

import java.util.List;

/**
 *
 * @author freon
 */
public class PredicateVO {

    private String name;
    private List<String> attributes;
    private int type;
    private String comment;

    public PredicateVO(String name, List<String> attributes, int type, String comment) {
        this.name = name;
        this.attributes = attributes;
        this.type = type;
        this.comment = comment;
    }

    public List<String> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<String> attributes) {
        this.attributes = attributes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String toString() {
        return "\nName: " + name +
                "\nType: " + type +
                "\nComment: " + comment +
                "\nAttribs: " + attributes;
    }
}
