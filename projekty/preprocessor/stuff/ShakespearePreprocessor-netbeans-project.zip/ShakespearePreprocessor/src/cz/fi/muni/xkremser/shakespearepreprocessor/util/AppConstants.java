/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *
sid     sentence ID
wid     word ID
chid    chunk ID
wvalue  word itself
svalue  sentence itself
tag     tag of word    tag(Spatio-temporal/JJ) = JJ
cht     chunk type     cht([NP-SBJ-1 Spatio-temporal/JJ data/NNS mining/NN NP-SBJ-1]) = [NP,SBJ,1]
pnp     in which (order) {PNP ... PNP} part it is located
chuWord if it is a chunk or a word
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.util;

/**
 *
 * @author freon
 */
public class AppConstants {

    public static final String SCHEMA_PATH = "lib/config.xsd";
    public static final String PATH_SETTINGS = "paths";
    public static final String UNKNOWN_STRING_VALUE = "unknown";
    public static final String SCRIPT_LOCATION = "http://lethe.fi.muni.cz/mbsp/mbsp.pl";
    public static final int UNKNOWN_NUMBER_VALUE = -1;

    public static final int PRED_TYPE_WORD_ID = 1;
    public static final int PRED_TYPE_META_ID = 2;
    public static final int PRED_TYPE_TAG_ID = 3;
    public static final int PRED_TYPE_CHUNK_ID = 4;
    public static final int PRED_TYPE_PNP_CHUNK_ID = 5;

    private static final int PRED_ATTR_OFFSET = 20;

    private static final int TAGGER_OFFSET = PRED_ATTR_OFFSET + 20;

    public static final int PRED_ATTR_SENTENCE_ID = PRED_ATTR_OFFSET + 0;
    public static final int PRED_ATTR_WORD_ID = PRED_ATTR_OFFSET + 1;
    public static final int PRED_ATTR_CHUNK_ID = PRED_ATTR_OFFSET + 2;
    public static final int PRED_ATTR_WORD_VALUE = PRED_ATTR_OFFSET + 3;
    public static final int PRED_ATTR_SENTENCE_VALUE = PRED_ATTR_OFFSET + 4;
    public static final int PRED_ATTR_TAG = PRED_ATTR_OFFSET + 5;
    public static final int PRED_ATTR_CHUNK_TYPE = PRED_ATTR_OFFSET + 6;
    public static final int PRED_ATTR_PNP = PRED_ATTR_OFFSET + 7;
    public static final int PRED_ATTR_CHUNK_WORD = PRED_ATTR_OFFSET + 8;

    public static final int TAGGER_NONE_ID = TAGGER_OFFSET + 1;
    public static final int TAGGER_MBSP_ID = TAGGER_OFFSET + 2;
    public static final int TAGGER_BRILL_ID = TAGGER_OFFSET + 3;

}