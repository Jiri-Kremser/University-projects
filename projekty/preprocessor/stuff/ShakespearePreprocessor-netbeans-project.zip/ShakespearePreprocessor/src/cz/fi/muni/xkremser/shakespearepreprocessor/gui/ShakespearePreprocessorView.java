/*
 * ShakespearePreprocessorView.java
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.gui;

import cz.fi.muni.xkremser.shakespearepreprocessor.*;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PathSettings;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppUtils;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.Charsets;
import java.awt.Toolkit;
import java.io.File;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import org.jdesktop.application.Task;

/**
 * The application's main frame.
 */
public class ShakespearePreprocessorView extends FrameView {

    public static final int INPUT_ID = 1;
    public static final int OUTPUT_ID = 2;
    public static final int CONFIG_ID = 3;
    private PathSettings pathSettings;
    private ShakespearePreprocessorApp app;
    private Preprocessor preprocessor;

    public ShakespearePreprocessorView(ShakespearePreprocessorApp app, PathSettings pathSettings) {
        super(app);
        this.app = app;

        initComponents();
        this.pathSettings = (pathSettings == null ? new PathSettings() : pathSettings);
        fillPaths();
        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);
        super.getFrame().setIconImage(Toolkit.getDefaultToolkit().getImage("lib/p.png"));

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {

            @Override
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String) (evt.getNewValue());
                    statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer) (evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = ShakespearePreprocessorApp.getApplication().getMainFrame();
            aboutBox = new ShakespearePreprocessorAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        ShakespearePreprocessorApp.getApplication().show(aboutBox);
    }

    @Action
    public void showInputChooser() {
        showFileChooser(INPUT_ID);
    }

    @Action
    public void showOutputChooser() {
        showFileChooser(OUTPUT_ID);
    }

    @Action
    public void showConfigChooser() {
        showFileChooser(CONFIG_ID);
    }

    public void showFileChooser(int type) {
        if (fileChooser == null) {
            fileChooser = new JFileChooser();
            fileChooser.setAcceptAllFileFilterUsed(false);
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        }
        if (type == CONFIG_ID) {
            FileFilter filter = new FileFilter() {

                @Override
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    String s = f.getName();
                    String ext = null;
                    int i = s.lastIndexOf('.');
                    if (i > 0 && i < s.length() - 1) {
                        ext = s.substring(i + 1).toLowerCase();
                    }
                    return ("xml".equals(ext));
                }

                @Override
                public String getDescription() {
                    return "XML file";
                }
            };
            fileChooser.addChoosableFileFilter(filter);
        }
        int returnVal = fileChooser.showOpenDialog(mainPanel);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            String path = null;
            try {
                path = fileChooser.getSelectedFile().getCanonicalPath();
                switch (type) {
                    case INPUT_ID:
                        inputField.setText(path);
                        pathSettings.setInputFilePath(path);
                        break;
                    case OUTPUT_ID:
                        outputField.setText(path);
                        pathSettings.setOutputFilePath(path);
                        break;
                    case CONFIG_ID:
                        configField.setText(path);
                        pathSettings.setConfigFilePath(path);
                        break;

                }

            } catch (IOException ex) {
                Logger.getLogger(ShakespearePreprocessorView.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

        @Action()
    public void cancel() {
        setRunning(false);
    }

    @Action
    public Task process() {
        if (validate()) {
            AppUtils.setRunning(true);
            pathSettings.setInputFilePath(inputField.getText());
            pathSettings.setOutputFilePath(outputField.getText());
            pathSettings.setConfigFilePath(configField.getText());
            AppUtils.saveSettings(pathSettings);
            Charsets charsets = new Charsets((String) jComboBox1.getSelectedItem(), (String) jComboBox2.getSelectedItem());
            preprocessor = new Preprocessor(pathSettings, charsets);
            Task task = preprocessor.process(getApplication());
            jButton2.setEnabled(true);
            jButton1.setEnabled(true);
            return task;
        } else {
            return null;
        }
    }

    @Action
    public void makePredicates() {
        preprocessor.makePredicates();
    }


    private boolean validate() {
        return validateInputFile() && validateConfigFile();
    }

    private boolean validateInputFile() {
        if (!new File(inputField.getText()).exists()) {
            JOptionPane.showMessageDialog(null, "Input file doesn't exist", "warning", JOptionPane.WARNING_MESSAGE);
            return false;
        } else {
            return true;
        }
    }

    private boolean validateConfigFile() {
        String path = configField.getText();
        if (!new File(path).exists()) {
            JOptionPane.showMessageDialog(null, "Config file doesn't exist", "warning", JOptionPane.WARNING_MESSAGE);
            return false;
        } else {
            return ConfigManager.validate(path,false);
        }
    }

    private void fillPaths() {
        this.inputField.setText(pathSettings.getInputFilePath());
        this.outputField.setText(pathSettings.getOutputFilePath());
        this.configField.setText(pathSettings.getConfigFilePath());
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        InputFilePanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        inputField = new javax.swing.JTextField();
        inputBrowse = new javax.swing.JButton();
        outputFilePanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        outputField = new javax.swing.JTextField();
        outputBrowse = new javax.swing.JButton();
        ProcessButton = new javax.swing.JButton();
        configFilePanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        configField = new javax.swing.JTextField();
        configBrowse = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem inputMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenuItem outputMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenuItem configMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenuItem processMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();

        mainPanel.setName("mainPanel"); // NOI18N

        InputFilePanel.setName("InputFilePanel"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(cz.fi.muni.xkremser.shakespearepreprocessor.ShakespearePreprocessorApp.class).getContext().getResourceMap(ShakespearePreprocessorView.class);
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N

        inputField.setText(resourceMap.getString("inputField.text")); // NOI18N
        inputField.setName("inputField"); // NOI18N

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(cz.fi.muni.xkremser.shakespearepreprocessor.ShakespearePreprocessorApp.class).getContext().getActionMap(ShakespearePreprocessorView.class, this);
        inputBrowse.setAction(actionMap.get("showInputChooser")); // NOI18N
        inputBrowse.setText(resourceMap.getString("inputBrowse.text")); // NOI18N
        inputBrowse.setName("inputBrowse"); // NOI18N

        javax.swing.GroupLayout InputFilePanelLayout = new javax.swing.GroupLayout(InputFilePanel);
        InputFilePanel.setLayout(InputFilePanelLayout);
        InputFilePanelLayout.setHorizontalGroup(
            InputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InputFilePanelLayout.createSequentialGroup()
                .addComponent(inputField, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inputBrowse))
            .addGroup(InputFilePanelLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addContainerGap())
        );
        InputFilePanelLayout.setVerticalGroup(
            InputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InputFilePanelLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(InputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inputBrowse)))
        );

        outputFilePanel.setName("outputFilePanel"); // NOI18N

        jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        outputField.setName("outputField"); // NOI18N

        outputBrowse.setAction(actionMap.get("showOutputChooser")); // NOI18N
        outputBrowse.setText(resourceMap.getString("outputBrowse.text")); // NOI18N
        outputBrowse.setName("outputBrowse"); // NOI18N

        javax.swing.GroupLayout outputFilePanelLayout = new javax.swing.GroupLayout(outputFilePanel);
        outputFilePanel.setLayout(outputFilePanelLayout);
        outputFilePanelLayout.setHorizontalGroup(
            outputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, outputFilePanelLayout.createSequentialGroup()
                .addComponent(outputField, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(outputBrowse))
            .addComponent(jLabel2)
        );
        outputFilePanelLayout.setVerticalGroup(
            outputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, outputFilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(outputFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(outputField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(outputBrowse)))
        );

        ProcessButton.setAction(actionMap.get("process")); // NOI18N
        ProcessButton.setText(resourceMap.getString("ProcessButton.text")); // NOI18N
        ProcessButton.setName("ProcessButton"); // NOI18N

        configFilePanel.setName("configFilePanel"); // NOI18N

        jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        configField.setName("configField"); // NOI18N

        configBrowse.setAction(actionMap.get("showConfigChooser")); // NOI18N
        configBrowse.setText(resourceMap.getString("configBrowse.text")); // NOI18N
        configBrowse.setName("configBrowse"); // NOI18N

        javax.swing.GroupLayout configFilePanelLayout = new javax.swing.GroupLayout(configFilePanel);
        configFilePanel.setLayout(configFilePanelLayout);
        configFilePanelLayout.setHorizontalGroup(
            configFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configFilePanelLayout.createSequentialGroup()
                .addComponent(configField, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(configBrowse))
            .addComponent(jLabel3)
        );
        configFilePanelLayout.setVerticalGroup(
            configFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configFilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(configFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(configField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(configBrowse)))
        );

        jComboBox1.setModel(new DefaultComboBoxModel(AppUtils.getAvailableCharsets()));
        jComboBox1.setSelectedItem("UTF-16");
        jComboBox1.setName("jComboBox1"); // NOI18N

        jLabel4.setText("Encoding:"); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        jLabel5.setText("Encoding:"); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        jComboBox2.setModel(new DefaultComboBoxModel(AppUtils.getAvailableCharsets()));
        jComboBox2.setSelectedItem("UTF-16");
        jComboBox2.setName("jComboBox2"); // NOI18N

        jButton1.setAction(actionMap.get("cancel")); // NOI18N
        jButton1.setText("Cancel"); // NOI18N
        jButton1.setName("jButton1"); // NOI18N

        jButton2.setAction(actionMap.get("makePredicates")); // NOI18N
        jButton2.setText("Make predicates"); // NOI18N
        jButton2.setName("jButton2"); // NOI18N

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(InputFilePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 187, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ProcessButton))
                    .addComponent(outputFilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(configFilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(InputFilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(outputFilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(configFilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ProcessButton)
                    .addComponent(jButton1)
                    .addComponent(jButton2)))
        );

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setMaximumSize(new java.awt.Dimension(55, 32767));
        fileMenu.setName("fileMenu"); // NOI18N

        inputMenuItem.setAction(actionMap.get("showInputChooser")); // NOI18N
        inputMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        inputMenuItem.setMnemonic('i');
        inputMenuItem.setText("Set input file"); // NOI18N
        inputMenuItem.setName("inputMenuItem"); // NOI18N
        inputMenuItem.setPreferredSize(new java.awt.Dimension(185, 23));
        fileMenu.add(inputMenuItem);

        outputMenuItem.setAction(actionMap.get("showOutputChooser")); // NOI18N
        outputMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        outputMenuItem.setMnemonic('o');
        outputMenuItem.setText("Set output file"); // NOI18N
        outputMenuItem.setName("outputMenuItem"); // NOI18N
        fileMenu.add(outputMenuItem);

        configMenuItem.setAction(actionMap.get("showConfigChooser")); // NOI18N
        configMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
        configMenuItem.setMnemonic('f');
        configMenuItem.setText("Set config file"); // NOI18N
        configMenuItem.setName("configMenuItem"); // NOI18N
        fileMenu.add(configMenuItem);

        processMenuItem.setAction(actionMap.get("process")); // NOI18N
        processMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_MASK));
        processMenuItem.setMnemonic('p');
        processMenuItem.setText("Process"); // NOI18N
        processMenuItem.setName("processMenuItem"); // NOI18N
        fileMenu.add(processMenuItem);

        jSeparator1.setName("jSeparator1"); // NOI18N
        fileMenu.add(jSeparator1);

        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 451, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 269, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusMessageLabel)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    public synchronized boolean isRunning() {
        return AppUtils.isRunning();
    }
    public synchronized void setRunning(boolean b) {
        AppUtils.setRunning(b);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel InputFilePanel;
    private javax.swing.JButton ProcessButton;
    private javax.swing.JButton configBrowse;
    private javax.swing.JTextField configField;
    private javax.swing.JPanel configFilePanel;
    private javax.swing.JButton inputBrowse;
    private javax.swing.JTextField inputField;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JButton outputBrowse;
    private javax.swing.JTextField outputField;
    private javax.swing.JPanel outputFilePanel;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    // End of variables declaration//GEN-END:variables
    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;
    private JDialog aboutBox;
    private JFileChooser fileChooser;
}
