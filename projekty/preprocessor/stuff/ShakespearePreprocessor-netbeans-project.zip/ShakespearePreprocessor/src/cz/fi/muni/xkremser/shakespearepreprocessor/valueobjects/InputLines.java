/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author freon
 */
public class InputLines {

    private LinkedList<String> linkedLines;

    public String toString() {
        if (linkedLines == null) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        for (String line : linkedLines) {
            sb.append(line).append('\n');
        }
        return sb.toString();
    }

    public List<String> getLines() {
        return linkedLines;
    }

    public void setLines(LinkedList<String> lines) {
        this.linkedLines = lines;
    }

    public void addLine(String line) {
        if (linkedLines == null) {
            linkedLines = new LinkedList<String>();
        }
        linkedLines.add(line);
    }

    public void removeXFirstLines(int x) {
        if (x > linkedLines.size() || linkedLines == null) {
            return;
        }
        for (int i = 0; i < x; i++) {
            linkedLines.removeFirst();
        }
    }

    public void removeXLastLines(int x) {
        if (x > linkedLines.size() || linkedLines == null) {
            return;
        }
        for (int i = 0; i < x; i++) {
            linkedLines.removeLast();
        }
    }

    public void removeLinesStartWith(String start) {
        Iterator it = linkedLines.iterator();
        while (it.hasNext()) {
            if (((String) it.next()).trim().startsWith(start)) {
                it.remove();
            }
        }
    }

    public void removeBlankLines() {
        Iterator it = linkedLines.iterator();
        while (it.hasNext()) {
            String line = (String) it.next();
            if ("".equals(line.trim())) {
                it.remove();
            }
        }
    }

    public void removeBetween(String start, String end) {
        LinkedList<String> copy = new LinkedList<String>();
        Iterator it = linkedLines.iterator();
        boolean deleteMode = false;

        while (it.hasNext()) {
            boolean deleteLine = false;
            String line = (String) it.next();
            if (deleteMode) {
                if (line.contains(end)) {
                    deleteMode = false;
                    line = line.substring(line.indexOf(end) + end.length(), line.length());
                } else {
                    deleteLine = true;
                    continue;
                }
            }
            if (!deleteMode && line.contains(start)) {
                if (!line.contains(end)) {
                    line = line.substring(0, line.indexOf(start));
                    deleteMode = true;
                } else {
                    line = line.substring(0, line.indexOf(start)) + line.substring(line.indexOf(end) + end.length(), line.length());
                    deleteMode = false;
                }
            }
            if (!deleteMode && line.contains(start)) {
                if (!line.contains(end)) {
                    line = line.substring(0, line.indexOf(start));
                    deleteMode = true;
                } else {
                    line = line.substring(0, line.indexOf(start)) + line.substring(line.indexOf(end) + end.length(), line.length());
                    deleteMode = false;
                }
            }
            if (!deleteMode && line.contains(start)) {
                if (!line.contains(end)) {
                    line = line.substring(0, line.indexOf(start));
                    deleteMode = true;
                } else {
                    line = line.substring(0, line.indexOf(start)) + line.substring(line.indexOf(end) + end.length(), line.length());
                    deleteMode = false;
                }
            }
            if (!deleteMode && line.contains(start)) {
                if (!line.contains(end)) {
                    line = line.substring(0, line.indexOf(start));
                    deleteMode = true;
                } else {
                    line = line.substring(0, line.indexOf(start)) + line.substring(line.indexOf(end) + end.length(), line.length());
                    deleteMode = false;
                }
            }
            if (!deleteLine) {
                copy.add(line);
            }
        }
        linkedLines = copy;
    }

    public void removeStopList(List<String> stopList) {
        Iterator it = linkedLines.iterator();
        LinkedList<String> copy = new LinkedList<String>();
        while (it.hasNext()) {
            String line = (String) it.next();
            for(int i = 0; i < stopList.size(); i++) {
                String stopWord = stopList.get(i).trim();
                if (line.contains(stopWord)) {
                    line = line.substring(0, line.indexOf(stopWord)) + line.substring(line.indexOf(stopWord) + stopWord.length(), line.length());
                }
            }
            copy.add(line);
        }
        linkedLines = copy;
    }
}
