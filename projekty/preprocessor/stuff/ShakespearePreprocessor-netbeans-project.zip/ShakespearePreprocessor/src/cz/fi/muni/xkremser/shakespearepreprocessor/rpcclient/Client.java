package cz.fi.muni.xkremser.shakespearepreprocessor.rpcclient;
/*
 * A sample Java code for the Termine Web Service.
 */

import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.rpc.*;
import javax.xml.rpc.encoding.XMLType;

public class Client
{

  public static void main(String[] args) throws Exception
  {

    String sentence = "Web service client is trying to contact this WSDL file. Technical terms are important for knowledge mining, especially in the bio-medical area where vast amount of documents are available.";

    String wsdlURL = "http://www.nactem.ac.uk/software/termine/webservice/termine.wsdl";
    URL url = new URL(wsdlURL);
    String targetNamespace = "urn:termine";
    String   serviceName = "termine";
    String      portName = "termine_porttype";
    String operationName = "analyze";
    QName    serviceQN   = new QName(targetNamespace, serviceName);
    QName       portQN   = new QName(targetNamespace, portName);
    QName  operationQN   = new QName(targetNamespace, operationName);

    try
    {
      ServiceFactory serviceFactory = ServiceFactory.newInstance();
      Service service = serviceFactory.createService(url, serviceQN);

      Call call = (Call) service.createCall();
      call.setProperty(Call.ENCODINGSTYLE_URI_PROPERTY, "");
      call.setProperty(Call.OPERATION_STYLE_PROPERTY, "wrapped");
      call.setTargetEndpointAddress("http://www.nactem.ac.uk:9000/termine");

      call.setPortTypeName(portQN);
      call.setOperationName(operationQN);

      call.removeAllParameters();
      call.addParameter("src",           XMLType.XSD_STRING, ParameterMode.IN);
      call.addParameter("input_format",  XMLType.XSD_STRING, ParameterMode.IN);
      call.addParameter("output_format", XMLType.XSD_STRING, ParameterMode.IN);
      call.addParameter("stoplist",      XMLType.XSD_STRING, ParameterMode.IN);
      call.addParameter("filter",        XMLType.XSD_STRING, ParameterMode.IN);

      Object[] inParams = new Object[] {sentence, "", "xml", "", ""};

      System.out.println(call.invoke(inParams));
    }
    catch (Exception e) {e.printStackTrace();}
  }
}
