/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor;

import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Config;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppConstants;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;

/**
 *
 * @author freon
 */
public class ConfigManager {

    public ConfigManager() {
    }

    public static Config loadXML(File file) {
        try {
            // create a JAXBContext capable of handling classes generated into
            // the cz.fi.muni.xkremser.shakespearepreprocessor.config.generated package
            JAXBContext jc = JAXBContext.newInstance("cz.fi.muni.xkremser.shakespearepreprocessor.config.generated");

            // create an Unmarshaller
            Unmarshaller u = jc.createUnmarshaller();
            // unmarshal a po instance document into a tree of Java content
            // objects composed of classes from the cz.fi.muni.xkremser.shakespearepreprocessor.config.generated package.
            JAXBElement<?> configElement = (JAXBElement<?>) u.unmarshal(file);
            Config config = (Config) configElement.getValue();
            return config;
        } catch (JAXBException je) {
            je.printStackTrace();
            return null;
        }
    }

    public static boolean validate(String path, boolean cli) {
        try {
            SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
            File schemaLocation = new File(AppConstants.SCHEMA_PATH);
            Schema schema = factory.newSchema(schemaLocation);
            Validator validator = (Validator) schema.newValidator();
            Source source = new StreamSource(path);
            validator.validate(source);
        } catch (SAXException ex) {
            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.INFO, "Config file is not valid.", ex);
            if (cli) {
                System.out.println("\n\nConfig file is not valid because:\n" + ex.getMessage().replace(". ", ".\n") + "\n");
            } else {
                JOptionPane.showMessageDialog(null, "Config file is not valid because:\n" + ex.getMessage().replace(". ", ".\n"), "warning", JOptionPane.WARNING_MESSAGE);
            }
            return false;
        } catch (IOException ex) {
            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
            if (cli) {
                System.out.println("\n\nConfig file is broken. Check path.\n");
            } else {
                JOptionPane.showMessageDialog(null, "Config file is broken. Check path.", "warning", JOptionPane.WARNING_MESSAGE);
            }
            return false;
        }
        return true;
    }
}
