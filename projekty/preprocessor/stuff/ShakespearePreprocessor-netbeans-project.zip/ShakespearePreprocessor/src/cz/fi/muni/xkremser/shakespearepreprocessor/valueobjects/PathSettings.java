/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects;

import java.io.Serializable;

/**
 *
 * @author freon
 */
public class PathSettings implements Serializable {
    private String inputFilePath;
    private String outputFilePath;
    private String configFilePath;

    public String getConfigFilePath() {
        return configFilePath;
    }

    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    public String getInputFilePath() {
        return inputFilePath;
    }

    public void setInputFilePath(String inputFilePath) {
        this.inputFilePath = inputFilePath;
    }

    public String getOutputFilePath() {
        return outputFilePath;
    }

    public void setOutputFilePath(String outputFilePath) {
        this.outputFilePath = outputFilePath;
    }

    @Override
    public String toString() {
        return this.inputFilePath + "\n" + this.outputFilePath +"\n"+ this.configFilePath;
    }
}
