/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.util;

import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PartOfText;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author freon
 */
public class PreprocessorUtils {

    private static Map<String, Pattern> patterns = new HashMap<String, Pattern>();

    public static List<String> getList(String path) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            String line = null;
            List returnList = new ArrayList();
            while ((line = br.readLine()) != null) {
                returnList.add(line.trim());
            }
            return returnList;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PreprocessorUtils.class.getName()).log(Level.SEVERE, "File " + path + " not found.", ex);
            return null;
        } catch (IOException ex) {
            Logger.getLogger(PreprocessorUtils.class.getName()).log(Level.SEVERE, "Unable to read from file " + path, ex);
            return null;
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(PreprocessorUtils.class.getName()).log(Level.SEVERE, "Unable to close from file " + path, ex);
                }
            }
        }
    }

    public static String processRegex(String regex, String line) {
        String reg1 = regex.substring(0, regex.indexOf("\\"));
        String reg2 = regex.substring(regex.indexOf("\\")+3, regex.length());

        if (patterns.get(reg1) == null) {
            patterns.put(reg1, Pattern.compile(".*"+reg1));
        }
        if (patterns.get(reg2) == null) {
            patterns.put(reg2, Pattern.compile(reg2+".*"));
        }

        Matcher m1 = patterns.get(reg1).matcher(line);
        Matcher m2 = patterns.get(reg2).matcher(m1.replaceAll(""));

        return m2.replaceAll("");
    }

    public static String restOfLine(String regex, String line) {
        String reg = regex.substring(regex.indexOf("\\")+3, regex.length());

        return line.substring(line.indexOf(reg)+reg.length(), line.length());
    }

    public static boolean match(String regex, String line) {
        if (patterns.get(regex) == null) {
            patterns.put(regex, Pattern.compile(".*"+regex+".*"));
        }
        return patterns.get(regex).matcher(line).matches();
    }

    public static void concatLines(List<PartOfText> input, boolean newLineSentenceDelimiter) {
        for(PartOfText pot : input) {
            StringBuffer sb = new StringBuffer();
            for (String line : pot.getTextLines()) {
                sb.append(line).append('\n');
            }
            pot.setText(sb.toString());
            if (!newLineSentenceDelimiter) {
                pot.setTextLines(Arrays.asList(sb.toString().split("[.?!]")));
            }
        }
    }
}
