/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor;

import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Output;
import cz.fi.muni.xkremser.shakespearepreprocessor.config.generated.Predicate;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppConstants;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PartOfText;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PredicateVO;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import javax.xml.bind.JAXBElement;

/**
 *
 * @author freon
 */
public class PredicateManager {

    private List<PredicateVO> predicates;
    private int taggerType;
    private static final String HEAD = "% made by shakespeare preprocessor\n\n\n";
    private String wordDelimiter;

    public PredicateManager(Output output, int taggerType) {
        this.taggerType = taggerType;
        this.predicates = new ArrayList<PredicateVO>(8);
        if (output.getWordDelimiter() != null && !"".equals(output.getWordDelimiter().trim())) {
            wordDelimiter = output.getWordDelimiter().trim();
        } else {
            wordDelimiter = " ";
        }
        List<Predicate> predicates = output.getPredicateNames().getPredicate();
        for (Predicate predicate : predicates) {
            List<String> attrList = new ArrayList<String>();
            List<JAXBElement<String>> bla = predicate.getAttributes().getAttributeOrMetaAttribute();
            for (JAXBElement<String> item : bla) {
                attrList.add(item.getValue().trim());
            }
            int type = -1;
            String sType = predicate.getType().trim();
            if ("meta".equals(sType)) {
                type = AppConstants.PRED_TYPE_META_ID;
            } else if ("word".equals(sType)) {
                type = AppConstants.PRED_TYPE_WORD_ID;
            } else if ("tag".equals(sType)) {
                type = AppConstants.PRED_TYPE_TAG_ID;
            } else if ("chunk".equals(sType)) {
                type = AppConstants.PRED_TYPE_CHUNK_ID;
            } else if ("PNPchunk".equals(sType)) {
                type = AppConstants.PRED_TYPE_PNP_CHUNK_ID;
            }
            String comment = predicate.getComment() != null ? predicate.getComment().trim() : null;
            PredicateVO newPredicate = new PredicateVO(predicate.getIdentifier().trim(), attrList, type, comment);
            this.predicates.add(newPredicate);
        }
    }

    public String toString() {
        return "Tagger: " + taggerType +
                "Predicates: " + predicates;
    }

    public List<PredicateVO> getPredicates() {
        return predicates;
    }

    public void setPredicates(List<PredicateVO> predicates) {
        this.predicates = predicates;
    }

    public int getTaggerType() {
        return taggerType;
    }

    public void setTaggerType(int taggerType) {
        this.taggerType = taggerType;
    }

    public String make(List<PartOfText> partsOfText) {
        StringBuilder sb = new StringBuilder(HEAD);

        for (PartOfText pot : partsOfText) {
            String[] sentences = null;
            int sid = pot.getSidOfFirstSentence();
            if (taggerType == AppConstants.TAGGER_MBSP_ID) {
                sentences = pot.getTaggedText().split("./.");
            } else if (taggerType == AppConstants.TAGGER_BRILL_ID) {
                sentences = pot.getTaggedLines().toArray(new String[]{});
            } else if (taggerType == AppConstants.TAGGER_NONE_ID) {
                sentences = pot.getTextLines().toArray(new String[]{});
            }

            int sentenceCounter = 0;
            for (String sentence : sentences) { // foreaech sentence
                for (PredicateVO predicate : predicates) { // foreach predicate
                    int type = predicate.getType();
                    if (type == AppConstants.PRED_TYPE_META_ID) {
                        String comment = predicate.getComment();
                        if (comment != null) {
                            if (comment.matches(".*svalue.*")) {
                                comment = comment.replaceAll("svalue", pot.getTextLines().get(sentenceCounter));
                            }
                            if (comment.matches(".*sid.*")) {
                                comment = comment.replaceAll("sid", String.valueOf(sid));
                            }
                        } else {
                            comment = predicate.getName();
                        }
                        sb.append("% ").append(comment).append('\n');
                        sb.append(predicate.getName()).append('(');
                        for (String key : predicate.getAttributes()) {
                            if ("sid".equals(key)) {
                                sb.append(sid);
                            } else if ("svalue".equals(key)) {
                                sb.append(pot.getTextLines().get(sentenceCounter));
                            } else {
                                String sValue = pot.getStringAttributes().get(key);
                                String sHCValue = PartOfText.getHardCodedAttributes().get(key);
                                if (sValue != null) {
                                    sb.append('"').append(sValue).append('"');
                                } else if (sHCValue != null) {
                                    sb.append('"').append(sHCValue).append('"');
                                } else {
                                    sb.append(pot.getNumberAttributes().get(key));
                                }
                            }
                            sb.append(',');
                        }
                        sb.deleteCharAt(sb.length() - 1).append(").\n\n"); // delete last comma
                    } else if (predicate.getType() == AppConstants.PRED_TYPE_WORD_ID || predicate.getType() == AppConstants.PRED_TYPE_TAG_ID) { // word/tag type
                        StringTokenizer st = new StringTokenizer(sentence, wordDelimiter);
                        int wId = 0;
                        StringBuilder words = new StringBuilder();
                        while (st.hasMoreTokens()) {
                            String token = st.nextToken();
                            if (token.contains("/")) {
                                wId++;
                                String[] parts = token.split("/");
                                words.append(predicate.getName() + "(");
                                for (String attr : predicate.getAttributes()) {
                                    if ("sid".equals(attr)) {
                                        words.append(sid).append(',');
                                    }
                                    if ("wid".equals(attr)) {
                                        words.append(wId).append(',');
                                    }
                                    if ("wvalue".equals(attr)) {
                                        words.append('"').append(parts[0]).append('"').append(',');
                                    }
                                    if ("tag".equals(attr)) {
                                        words.append('"').append(parts[1]).append('"').append(',');
                                    }
                                }
                                words.deleteCharAt(words.length() - 1).append(").\t");

                            } else if (taggerType == AppConstants.TAGGER_NONE_ID) {
                                wId++;
                                words.append(predicate.getName() + "(");
                                for (String attr : predicate.getAttributes()) {
                                    if ("sid".equals(attr)) {
                                        words.append(sid).append(',');
                                    }
                                    if ("wid".equals(attr)) {
                                        words.append(wId).append(',');
                                    }
                                    if ("wvalue".equals(attr)) {
                                        words.append('"').append(token).append('"').append(',');
                                    }
                                }
                                words.deleteCharAt(words.length() - 1).append(").\t");
                            }
                        }
                        String comment = "";
                        if (predicate.getComment() == null) {
                            if (predicate.getType() == AppConstants.PRED_ATTR_WORD_ID) {
                                comment = "word";
                            } else {
                                comment = "tag";
                            }
                        } else {
                            comment = predicate.getComment();
                        }
                        sb.append("% ").append(comment).append("\n").append(words).append("\n\n");
                    } else if (predicate.getType() == AppConstants.PRED_TYPE_CHUNK_ID) { // tag type
                        StringTokenizer st = new StringTokenizer(sentence, wordDelimiter);
                        StringBuilder chunks = new StringBuilder();
                        boolean inCh = false;
                        int wId = 0, chId = 0;
                        String cht = "";
                        while (st.hasMoreTokens()) {
                            String token = st.nextToken();
                            if (token.startsWith("[")) {
                                chId++;
                                cht = token.replaceAll("(\\p{Upper}+)", "\"$1\"").replaceAll("-", ",") + "]";
                                inCh = true;
                            } else if (token.endsWith("]")) {
                                inCh = false;
                            } else if (token.contains("/")) {
                                wId++;
                                if (inCh) {
                                    chunks.append(predicate.getName() + "(");
                                    for (String attr : predicate.getAttributes()) {
                                        if ("sid".equals(attr)) {
                                            chunks.append(sid).append(',');
                                        }
                                        if ("wid".equals(attr)) {
                                            chunks.append(wId).append(',');
                                        }
                                        if ("chid".equals(attr)) {
                                            chunks.append(chId).append(',');
                                        }
                                        if ("cht".equals(attr)) {
                                            chunks.append('"').append(cht).append('"').append(',');
                                        }
                                    }
                                    chunks.deleteCharAt(chunks.length() - 1).append(").\t");
                                }
                            }
                            sb.append("%").append(predicate.getComment() != null ? predicate.getComment() : "chunk").append("\n").append(chunks).append("\n\n");
                        }
                    } else if (predicate.getType() == AppConstants.PRED_TYPE_PNP_CHUNK_ID) { // tag type
                        StringTokenizer st = new StringTokenizer(sentence, wordDelimiter);
                        boolean inPNP = false;
                        int pnp = 0, wId = 0, chId = 0;
                        StringBuilder pnpChunks = new StringBuilder();
                        while (st.hasMoreTokens()) {
                            String token = st.nextToken();
                            if (token.startsWith("{PNP")) {
                                inPNP = true;
                                pnp++;
                            } else if (token.endsWith("PNP}")) {
                                inPNP = false;
                            } else if (token.startsWith("[")) {
                                chId++;
                            } else if (token.endsWith("]") && inPNP) {
                                pnpChunks.append(predicate.getName() + "(");
                                for (String attr : predicate.getAttributes()) {
                                    if ("sid".equals(attr)) {
                                        pnpChunks.append(sid).append(',');
                                    }
                                    if ("pnp".equals(attr)) {
                                        pnpChunks.append(pnp).append(',');
                                    }
                                    if ("chid".equals(attr)) {
                                        pnpChunks.append(chId).append(',');
                                    }
                                    if ("chuWord".equals(attr)) {
                                        pnpChunks.append("\"chunk\"");
                                    }
                                }
                                pnpChunks.deleteCharAt(pnpChunks.length() - 1).append(").\t");
                            } else if (token.contains("/")) {
                                wId++;
                                if (inPNP) {
                                    pnpChunks.append(predicate.getName() + "(");
                                    for (String attr : predicate.getAttributes()) {
                                        if ("sid".equals(attr)) {
                                            pnpChunks.append(sid).append(',');
                                        }
                                        if ("pnp".equals(attr)) {
                                            pnpChunks.append(pnp).append(',');
                                        }
                                        if ("chid".equals(attr)) {
                                            pnpChunks.append(chId).append(',');
                                        }
                                        if ("chuWord".equals(attr)) {
                                            pnpChunks.append("\"word\"").append(',');
                                        }
                                    }
                                    pnpChunks.deleteCharAt(pnpChunks.length() - 1).append(").\t");
                                }
                            }
                        }
                        sb.append("%").append(predicate.getComment() != null ? predicate.getComment() : "PNP chunk").append("\n").append(pnpChunks).append("\n\n");
                    }
                }
                sid++;
                sentenceCounter++;
            }
        }
        return sb.toString();
    }
}
