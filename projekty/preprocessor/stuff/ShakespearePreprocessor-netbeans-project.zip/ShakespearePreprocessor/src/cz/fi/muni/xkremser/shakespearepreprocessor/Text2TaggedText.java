package cz.fi.muni.xkremser.shakespearepreprocessor;

import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppConstants;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;

/**
 *
 * @author Petra Večeřová
 */
public class Text2TaggedText {

    private HttpClient client = new HttpClient();
    private PostMethod post = new PostMethod(AppConstants.SCRIPT_LOCATION);

    {
        post.addParameters(new NameValuePair[]{new NameValuePair("input", null)});

    }

    // parsed text is without line breaks, we must convert it to vertical again
    // sample output:
    // [INTJ hello/UH INTJ] [NP boy/NN NP] [ADVP how/WRB ADVP] 
    // [/( [NP Joe/NNP NP] ]/) [VP-1 are/VBP VP-1] [NP-OBJ-1 you/PRP NP-OBJ-1] ?/. 
    private String callMBSP(String input) throws IOException {
        int retCode = client.executeMethod(post);
        if (retCode != HttpStatus.SC_OK) {
            System.err.println("Error calling MBSP, HTTP returned " + HttpStatus.getStatusText(retCode));
        }
        post.setParameter("input", input);
        String result = post.getResponseBodyAsString();
        post.releaseConnection();
        if (input!=null && !"".equals(input) && "".equals(result)) {
            result = null;
        }
        return result;
    }

    protected String doConversion(String input) throws IOException {
        return callMBSP(input);
    }

    public void run(String inputFile, String outputFile) {
        FileInputStream fis = null;
        FileOutputStream fos = null;
        OutputStreamWriter osw = null;

        try {
            fis = new FileInputStream(inputFile);
            int len = (int) (new File(inputFile).length());
            byte buf[] = new byte[len];
            fis.read(buf);
            String input = new String(buf);
            String output = doConversion(input);
            fos = new FileOutputStream(outputFile);
            osw = new OutputStreamWriter(fos);
            osw.write(output);
        } catch (IOException ex) {
            System.err.println("Unable to read from file. " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (osw != null) {
                    osw.close();
                }
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException ex) {
                System.err.println("Unable to close stream. " + ex.getMessage());
            }
        }
    }

    static public void main(String[] args) {
        Text2TaggedText t2tt = new Text2TaggedText();
        if (args.length == 2) {
            t2tt.run(args[0], args[1]);
        } else {
            System.out.println("Usage: Text2TaggedText <input_file> <output_file>");
        }
    }
}
