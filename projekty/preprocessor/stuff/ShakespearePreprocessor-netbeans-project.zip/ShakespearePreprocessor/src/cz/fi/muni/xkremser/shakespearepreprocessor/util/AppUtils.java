/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cz.fi.muni.xkremser.shakespearepreprocessor.util;

import cz.fi.muni.xkremser.shakespearepreprocessor.ShakespearePreprocessorApp;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PathSettings;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author freon
 */
public class AppUtils {
    private static volatile boolean running = false;

    public static String[] getAvailableCharsets() {
        return Charset.availableCharsets().keySet().toArray(new String[] {""});
    }

    public static Map<String, String> copyStrMap(Map<String, String> input) {
        Map<String, String> returnMap = new HashMap<String, String>();
        for (String key : input.keySet()) {
            returnMap.put(key, input.get(key));
        }
        return returnMap ;
    }

    public static Map<String, Integer> copyIntMap(Map<String, Integer> input) {
        Map<String, Integer> returnMap = new HashMap<String, Integer>();
        for (String key : input.keySet()) {
            returnMap.put(key, input.get(key));
        }
        return returnMap ;
    }

    public static synchronized boolean isRunning() {
        return AppUtils.running;
    }

    public static synchronized void setRunning(boolean running) {
        AppUtils.running = running;
    }

    public static PathSettings loadSettings() {
        if (!new File(AppConstants.PATH_SETTINGS).exists()) {
            return null;
        }
        ObjectInputStream bis = null;
        try {
            bis = new ObjectInputStream(new FileInputStream(AppConstants.PATH_SETTINGS));
            return (PathSettings) bis.readObject();
        } catch (IOException ex) {
            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.INFO, null, ex);
            return new PathSettings();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
            return new PathSettings();
        } finally {
            try {
                if (bis != null) {
                    bis.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void saveSettings(PathSettings pathSettings) {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(AppConstants.PATH_SETTINGS));
            oos.writeObject(pathSettings);
        } catch (IOException ex) {
            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                oos.close();
            } catch (IOException ex) {
                Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
