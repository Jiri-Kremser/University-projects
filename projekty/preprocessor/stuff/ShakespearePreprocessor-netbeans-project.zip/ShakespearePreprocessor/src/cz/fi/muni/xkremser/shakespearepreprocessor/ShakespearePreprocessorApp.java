/*
 * ShakespearePreprocessorApp.java
 */
package cz.fi.muni.xkremser.shakespearepreprocessor;

import cz.fi.muni.xkremser.shakespearepreprocessor.gui.ShakespearePreprocessorView;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppConstants;
import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppUtils;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.Charsets;
import cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects.PathSettings;
import edu.mit.csail.brill.BrillTagger;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.util.EventObject;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.jdesktop.application.Application;
import org.jdesktop.application.Application.ExitListener;
import org.jdesktop.application.SingleFrameApplication;

/**
 * The main class of the application.
 */
public class ShakespearePreprocessorApp extends SingleFrameApplication {

    /**
     * At startup create and show the main frame of the application.
     */
    @Override
    protected void startup() {
        show(new ShakespearePreprocessorView(this, AppUtils.loadSettings()));
    }

    /**
     * This method is to initialize the specified window by injecting resources.
     * Windows shown in our application come fully initialized from the GUI
     * builder, so this additional configuration is not needed.
     */
    @Override
    protected void configureWindow(java.awt.Window root) {
    }

    /**
     * A convenient static getter for the application instance.
     * @return the instance of ShakespearePreprocessorApp
     */
    public static ShakespearePreprocessorApp getApplication() {
        return Application.getInstance(ShakespearePreprocessorApp.class);
    }

    public static void requiredParameter(CommandLine line, String name,
            Options options) {
        System.out.println("Required parameter missing: " + name);
        printHelp(options);
        System.exit(1);

    }

    public static void printHelp(Options options) {
        HelpFormatter help = new HelpFormatter();
        help.printHelp("prepr.sh", options, true);
    }

    private static Preprocessor parseLine(String... args) {
        Options options = new Options();
        Option input = OptionBuilder.withArgName("file").withLongOpt("input").hasArg().withDescription("use given file as input").create("i");
        Option output = OptionBuilder.withArgName("file").withLongOpt("output").hasArg().withDescription("use given file as output").create("o");
        Option config = OptionBuilder.withArgName("file").withLongOpt("config").hasArg().withDescription("use given file as config").create("c");
        Option encoding = OptionBuilder.withArgName("charset").withLongOpt("encoding").hasArg().withDescription("use given encoding for both input and output files").create("e");


        options.addOption(input);
        options.addOption(output);
        options.addOption(config);
        options.addOption(encoding);
        options.addOption("help", false, "print this help");
        CommandLineParser parser = new PosixParser();

        PathSettings settings = new PathSettings();
        Charsets charsets = new Charsets("UTF-16", "UTF-16");
        try {
            CommandLine line = parser.parse(options, args);
            if (line.hasOption("help")) {
                printHelp(options);
                System.exit(0);
            }
            if (!line.hasOption("i")) {
                requiredParameter(line, "-i input file", options);
            } else {
                settings.setInputFilePath(line.getOptionValue("i"));
            }
            if (!line.hasOption("c")) {
                requiredParameter(line, "-c congig file", options);
            } else {
                settings.setConfigFilePath(line.getOptionValue("c"));
            }
            if (!line.hasOption("o")) {
                requiredParameter(line, "-o output file", options);
            } else {
                settings.setOutputFilePath(line.getOptionValue("o"));
            }
            if (line.hasOption("e")) {
                charsets.setInputCharset(line.getOptionValue("e"));
                charsets.setOutputCharset(line.getOptionValue("e"));
            }
        } catch (ParseException ex) {
            printHelp(options);
            System.err.println("\nParsing failed.  Reason: " + ex.getMessage() + "\n");
            System.exit(1);
        }
        if (!new File(settings.getInputFilePath()).exists()) {
            System.out.println("\nInput file " + settings.getInputFilePath() + " doesn't exist.\n");
            printHelp(options);
            System.exit(1);
        }
        if (!new File(settings.getConfigFilePath()).exists()) {
            System.out.println("\nConfig file" + settings.getConfigFilePath() + " doesn't exist.\n");
            printHelp(options);
            System.exit(1);
        }
        if (!ConfigManager.validate((settings.getConfigFilePath()), true)) {
            printHelp(options);
            System.exit(1);
        }
        return new Preprocessor(settings, charsets);
    }

    /**
     * Main method launching the application.
     */
    public static void main(String[] args) {
//        try { // Call Web Service Operation
//            com.cdyne.ws.Check service = new com.cdyne.ws.Check();
//            com.cdyne.ws.CheckSoap port = service.getCheckSoap();
//            // TODO initialize WS operation arguments here
//            java.lang.String bodyText = "";
//            java.lang.String licenseKey = "";
//            // TODO process result here
//            com.cdyne.ws.DocumentSummary result = port.checkTextBody(bodyText, licenseKey);
//            System.out.println("Result = " + result);
//        } catch (Exception ex) {
//            // TODO handle custom exceptions here
//        }
//        Termine_porttype_Stub stub = new Termine_porttype_Stub(null);
//        try {
//            System.out.println("output is :" + stub.analyze("hello", null, null, null, null));
//        } catch (RemoteException ex) {
//            Logger.getLogger(ShakespearePreprocessorApp.class.getName()).log(Level.SEVERE, null, ex);
//        }
        Logger.getLogger(ShakespearePreprocessorApp.class.getName()).setLevel(Level.ALL);
        if (args.length > 0) {
            Preprocessor p = parseLine(args);
            p.process(null);
            p.makePredicates();
        } else {
            launch(ShakespearePreprocessorApp.class, args);
        }
    }
}
