/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.fi.muni.xkremser.shakespearepreprocessor.valueobjects;

import cz.fi.muni.xkremser.shakespearepreprocessor.util.AppUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author freon
 */
public class PartOfText {

    private Map<String, String> stringAttributes;
    private Map<String, Integer> numberAttributes;
    private static Map<String, String> hardCodedAttributes;

    private List<String> textLines;
    private List<String> taggedLines;
    private String text;
    private String taggedText;
    private int sidOfFirstSentence;

    public PartOfText(List<String> textLines) {
        if (this.stringAttributes == null) {
            this.stringAttributes = new HashMap<String,String>();
        }
        if (this.numberAttributes == null) {
            this.numberAttributes = new HashMap<String,Integer>();
        }
        this.textLines = textLines;
    }

    public PartOfText(String attrName, String stringAttribute, List<String> textLines) {
        if (this.stringAttributes == null) {
            this.stringAttributes = new HashMap<String,String>();
        }
        if (this.numberAttributes == null) {
            this.numberAttributes = new HashMap<String,Integer>();
        }
        stringAttributes.put(attrName, stringAttribute);
        this.textLines = textLines;
    }

    public PartOfText(String attrName, int intAttribute, List<String> textLines) {
        if (this.stringAttributes == null) {
            this.stringAttributes = new HashMap<String,String>();
        }
        if (this.numberAttributes == null) {
            this.numberAttributes = new HashMap<String, Integer>();
        }
        numberAttributes.put(attrName, intAttribute);
        this.textLines = textLines;
    }

    public void addStringAttr(String name, String value) {
        stringAttributes.put(name, value);
    }

    public void addNumberAttr(String name, int value) {
        numberAttributes.put(name, value);
    }

    public Map<String, Integer> getNumberAttributes() {
        if (numberAttributes == null) {
            this.numberAttributes = new HashMap<String, Integer>();
        }
        return numberAttributes;
    }

    public void setNumberAttributes(Map<String, Integer> numberAttributes) {
        this.numberAttributes = numberAttributes;
    }

    public Map<String, String> getStringAttributes() {
        return stringAttributes;
    }

    public void setStringAttributes(Map<String, String> stringAttributes) {
        this.stringAttributes = stringAttributes;
    }


    public List<String> getTextLines() {
        return textLines;
    }

    public void setTextLines(List<String> textLines) {
        this.textLines = textLines;
    }

    public static Map<String, String> getHardCodedAttributes() {
        return hardCodedAttributes;
    }

    public int getSidOfFirstSentence() {
        return sidOfFirstSentence;
    }

    public void setSidOfFirstSentence(int sidOfFirstSentence) {
        this.sidOfFirstSentence = sidOfFirstSentence;
    }

    public static void setHardCodedAttributes(Map<String, String> hardCodedAttributes) {
        PartOfText.hardCodedAttributes = hardCodedAttributes;
    }

    public static void addHardCodedAttribute(String name, String attr) {
        if (hardCodedAttributes == null) {
            hardCodedAttributes = new HashMap<String, String>();
        }
        hardCodedAttributes.put(name, attr);
    }

    public void addLine(String line) {
        this.textLines.add(line);
    }

    public void copyAttribs(PartOfText pot){
        setNumberAttributes(AppUtils.copyIntMap(pot.getNumberAttributes()));
        setStringAttributes(AppUtils.copyStrMap(pot.getStringAttributes()));
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<String> getTaggedLines() {
        return taggedLines;
    }

    public void setTaggedLines(List<String> taggedLines) {
        this.taggedLines = taggedLines;
    }

    public String getTaggedText() {
        return taggedText;
    }

    public void setTaggedText(String taggedTexf) {
        this.taggedText = taggedTexf;
    }

    public String toString() {
        return  "\nHC string attributes:\n" + this.hardCodedAttributes +
                "\nString attributes:\n" + this.stringAttributes +
                "\nNumber attributes:\n" + this.numberAttributes +
                "\nlines number:\n" + this.textLines.size() +
                "\nfirst sid:\n" + this.getSidOfFirstSentence() +
                "\ntext:\n" + this.textLines + "\n\n#############################" +
                "\ntagged text:\n" + this.taggedText + "\n\n#############################";
    }
}
