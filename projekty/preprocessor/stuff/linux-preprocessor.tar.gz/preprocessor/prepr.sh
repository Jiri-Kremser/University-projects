#!/bin/sh
java -Xmx512m -Xms512m -Djava.library.path="./lib" -jar ./ShakespearePreprocessor.jar $*
