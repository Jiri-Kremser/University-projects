Ovl�d�n�:
=========

sipky: translace
q,w,e: y rotace
a,s,d: x rotace
x,c,v: z rotace
ESC  : konec

# Je to zatim jenom ta slibena betaverze. Robota dodam pozdeji. 
Jiri Kremser