#!/bin/sh
java -jar neurocars.jar -mode race -scenario ./config/scenario/race.properties
