#!/bin/sh
java -jar neurocars.jar -mode train -input ./car_setup1_replay_pack.txt -network ./config/neuralnetwork/new.ser
