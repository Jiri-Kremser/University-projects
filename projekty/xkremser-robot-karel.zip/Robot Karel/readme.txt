Ovladani
========
myska : translace/rotace
    s : vypne/zapne svetla
    t : vypne/zapne textury
    s : vypne/zapne svetla

    p : vypne/zapne vykreslovani polygonu
    m : vypne/zapne mlhu
ESC/q : konec

Vypracoval Jirka Kremser jako ulohu do predmetu PV112 a PB009.