#ifndef _KAREL_

#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>

#define P_J 1
#define P_I 2
#define P_R 3
#define P_K 4
#define P_A 5

#define P_K2 6
#define P_R2 7
#define P_E 8
#define P_M 9
#define P_S 10
#define P_E2 11
#define P_R3 12
#define P_I2 13

#define R_HLAVA 13
#define R_OKO 14
#define R_ZOR 15
#define R_ZUBY 16
#define R_TRUP 17
#define R_RUKA 18
#define R_NOHA 19
#define POCET_P 13

using namespace std;

//PROTOTYPY
void makeList(int,char*);
int loadTextures(void);
int bitmapLoad(int, const char*);
void jdi(int,int);
void otoc(int,int);
void uchop(int,int);
void vyjed(int cas);
void animuj(int);
void initpole(void);
void makeList(int which,char* soubor);
void makeLists(void);
void initpole(void);
int loadTextures(void);


#define _KAREL_
#endif

