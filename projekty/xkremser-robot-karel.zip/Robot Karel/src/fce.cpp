#include "hl.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>


// ----------------- NACTE ZE SOUBORU POTREBNE DATA A VYTVORI DISPLAY LIST
// -----------------------------------------------------------------------
void makeList(int which,char* soubor){
     
    char buffer[128];
    float vrcholy[9999][3];
    float normaly[9999][3];
    long int face[9000][3];//index/index bodu/index typu
    long int facenum=0;
    long int vrcholnum=0;
    long int normalnum=0;
    int suda=1;
    long int i=0,j=0,k=0;
    
    FILE *in = fopen(soubor, "r");
    if (in==NULL) {
      std::cerr<<"Nepodarilo se otevrit soubor "<<soubor<<std::endl;
      exit(1);
    }
    
    while (!feof(in)){
      fgets(buffer, 127, in);
      if ((buffer[0]=='v')&&(buffer[1]=='n')){ //normala
        sscanf(buffer + 2, "%f %f %f", &normaly[normalnum][0],&normaly[normalnum][1], &normaly[normalnum][2]);
        normalnum++;
      }
      else if ((buffer[0]=='v')&&(buffer[1]!='t')){ //vertex
        sscanf(buffer + 1, "%f %f %f", &vrcholy[vrcholnum][0],&vrcholy[vrcholnum][1], &vrcholy[vrcholnum][2]);
        vrcholnum++;
      }  

      if (buffer[0]=='f'){
        char* pch=strtok(buffer+2,"/");
        while (pch != NULL){
           if (suda){
             suda=0;
             sscanf(pch,"%d" ,&face[facenum][0]);
           }
           else {
             suda=1;
             sscanf(pch,"%d" ,&face[facenum][1]);
             facenum++;
           }
          pch = strtok (NULL, "/\n ");
        }
      }
    }
        
    glNewList(which,GL_COMPILE);
      glBegin(GL_TRIANGLES);
       float l=0.1; // manualni scale
       for (int i=0;i<facenum;i+=3){
         glNormal3f(normaly[ face[i][1] -1][0],normaly[ face[i][1] -1][1],normaly[ face[i][1] -1][2]);
         glVertex3f(vrcholy[ face[i][0] -1][0]*l,vrcholy[ face[i][0] -1][1]*l,vrcholy[ face[i][0] -1][2]*l);
         
         glNormal3f(normaly[ face[i+1][1] -1][0],normaly[ face[i+1][1] -1][1],normaly[ face[i+1][1] -1][2]);
         glVertex3f(vrcholy[ face[i+1][0] -1][0]*l,vrcholy[ face[i+1][0] -1][1]*l,vrcholy[ face[i+1][0] -1][2]*l);
         
         glNormal3f(normaly[ face[i+2][1] -1][0],normaly[ face[i+2][1] -1][1],normaly[ face[i+2][1] -1][2]);
         glVertex3f(vrcholy[ face[i+2][0] -1][0]*l,vrcholy[ face[i+2][0] -1][1]*l,vrcholy[ face[i+2][0] -1][2]*l);
       }
       
      glEnd();
    glEndList();   
  return;
}

void makeLists(void){
    // CASTI ROBOTA
    makeList(R_HLAVA,"obj/robot/hlava.obj");
    makeList(R_OKO,"obj/robot/oko.obj");
    makeList(R_ZOR,"obj/robot/zornicka.obj");
    makeList(R_TRUP,"obj/robot/trup.obj");
    makeList(R_ZUBY,"obj/robot/zuby.obj");
    makeList(R_NOHA,"obj/robot/noha.obj");
    makeList(R_RUKA,"obj/robot/ruka.obj");
    // JMENO
    makeList(P_J,"obj/pismena/j.obj");
    makeList(P_I,"obj/pismena/i.obj");
    makeList(P_R,"obj/pismena/r.obj");
    makeList(P_K,"obj/pismena/k.obj");
    makeList(P_A,"obj/pismena/a.obj");
    makeList(P_E,"obj/pismena/e.obj");
    makeList(P_M,"obj/pismena/m.obj");
    makeList(P_S,"obj/pismena/s.obj");
    return;
}
