/////////////////////////////////////////////////////////////////
///                                                            //
//     ////////     ///////   ///////    ///////   /////////   //
//     ///    ///  ///   ///  ///   //  ///   ///     ///      //
//     ///    ///  ///   ///  ///   //  ///   ///     ///      //
//     ////////    ///   ///  //////    ///   ///     ///      //
//     ////  //    ///   ///  ///   //  ///   ///     ///      //
//     ///    ///  ///   ///  ///   //  ///   ///     ///      //
//     ///    ///   ///////   ///////    ///////      ///      //
//                                                            ///
/////////////////////////////////////////////////////////////////
//                                                   Jiri Kremser
#include "hl.h"


int textures[4]; 
enum {                                          // operace, ktere se mohou provadet s mysi:
    ROTATE,                                     // rotace objektu
    TRANSLATE,                                  // posun objektu
} operation=ROTATE;

int xnew=0, ynew=0, znew=20;                  // soucasna pozice mysi, ze ktere se pocitaji rotace a posuvy
int xold=0, yold=0, zold=30;                  // minula pozice mysi, ze ktere se pocitaji rotace a posuvy
int xx, yy, zz;                               // bod, ve kterem se nachazi kurzor mysi


float Rx=-15,Rz=0;
float pom,pom2=1;
int rotnoha=0,rotruka=0;
int ram=0,Rrotace=0;
int delay=40;
GLboolean svetlo=true;
GLboolean mlha=true;
GLboolean textury=true;
GLint cary=GL_FILL;

int windowWidth;                              // sirka okna
int windowHeight;                             // vyska okna


// materialy, svetlo a spol.
GLfloat robotAmbient[]={0.25f, 0.25f, 0.25f, 1.0f};// ambientni slozka barvy materialu
GLfloat robotDiffuse[]={0.35f, 0.35f, 0.6f, 1.0f}; // difuzni slozka barvy materialu
GLfloat robotSpecular[]={0.5f, 0.5f, 0.7f, 1.0f};// barva odlesku
GLfloat robotShininess[]={65.0f};                // faktor odlesku

GLfloat belmoAmbient[]={0.25f, 0.25f, 0.25f, 1.0f};
GLfloat belmoDiffuse[]={1.0f, 1.0f, 1.0f, 1.0f};
GLfloat belmoShininess[]={15.0f};
GLfloat belmoSpecular[]={0.3f, 0.3f, 0.3f, 1.0f};

GLfloat zorAmbient[]={0.25f, 0.25f, 0.25f, 1.0f};
GLfloat zorDiffuse[]={0.0f, 0.0f, 0.0f, 1.0f};
GLfloat zorShininess[]={15.0f};
GLfloat zorSpecular[]={0.3f, 0.3f, 0.3f, 1.0f};

GLfloat pisAmbient[]={0.4f, 0.4f, 0.4f, 1.0f};
GLfloat pisDiffuse[]={0.2f, 0.6f, 0.4f, 1.0f};
GLfloat pisShininess[]={50.0f};
GLfloat pisSpecular[]={1.0f, 1.0f, 1.0f, 1.0f};

GLfloat skyAmbient[]={0.2f, 0.2f, 0.2f, 1.0f};
GLfloat skyDiffuse[]={1.0f, 1.0f, 0.7f, 1.0f};
GLfloat skyShininess[]={90.0f};
GLfloat skySpecular[]={0.0f, 1.0f, 1.0f, 1.0f};


GLfloat fogColor[4]={0.5,0.5,0.6,1.0};      // barva mlhy
GLfloat fogDensity=0.0005f;                 // hustota mlhy
int fogMode = GL_EXP;                       // zpusob sireni


//GLfloat light_position[]={1.0f, 1.0f, 0.0f, 0.0f};// pozice svetla: nula na konci->bodove svetlo
GLfloat light_color[]={1.0f, 1.0f, 1.0f};           // barva svetla
GLfloat light_position[] = {0,0,-4,1.0};            //w=0:infinite
//GLfloat light_color[] = {0.6,0.1,1,1};
    




//---------------------------------------------------------------------
// Nacteni a vytvoreni vsech textur
//---------------------------------------------------------------------
int loadTextures(void){
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);          // zpusob ulozeni bytu v texure
    glGenTextures(4,(GLuint*) textures);                     // vytvoreni jmena textur
    if (bitmapLoad(textures[1],"textury/dlazdice.bmp"))   exit(0);
//    if (bitmapLoad(textures[2],    "textury/textura2.bmp"))    exit(0);
}


//---------------------------------------------------------------------
// SEKVENCE POHYBU
//---------------------------------------------------------------------
int start=0;
int akce=start,pisvruce=0;

// uhly rotaci robota a vzdalenosti chuze
//          0000 1111 2222 3333 4444 5555 6666 7777 8888 9999
int casy[]={-150,190 ,-120,20  ,-90 ,90  ,30  ,45  ,110 ,-45 , // 0 - 9
            -30 ,-100,-90 ,10  ,90  ,11  ,30  ,40  ,-6  ,54  , //10 - 19
             6  ,-30 ,-145,142 ,-135,22  ,-90 ,30  , 30 , 60 , //20 - 29
             110,-45 ,8   ,-30 ,125 ,215 , 145,55  , 90 , 10 , //30 - 39
             90 , -10,-90 ,90  ,10  ,-90 ,10  ,20  ,112 ,-20 , //40 - 49
            -10 ,-165, 104,75  , 85 , 90 ,10  ,2   ,90  ,-2  , //50 - 59
            -10 ,-90 ,-90 ,50  ,90  ,3   ,10  ,20  ,54  ,170 , //60 - 69
            -54 ,-10 ,-135,176 ,135 ,10  ,-5  ,94  ,5   ,-10 , //70 - 79
            -180,88  ,-90 ,77  ,-90 ,10  ,20  ,50  ,103 ,-50 , //80 - 89
            20  ,-10 ,-180,90  ,91  ,69  ,90  ,10  ,45  ,24  , //90 - 99
            -45 ,81  ,-10 ,-95 ,90  ,17  ,-90 ,10  ,80  ,-90 , //100 - 109
            30  ,91  ,16  ,-10 ,-90 ,-90 ,14  ,90  ,10  ,55  , //110 - 119
            190 ,-55 ,4   ,-10 , 52                            //120 - 129
           };  
void animuj(int cas){
  int rotrych=1,posrych=10;
     
  if(cas==0){ //okamzik kdy skoncila akce
    akce++;
    cas=casy[akce-start]; 
  }
  switch (akce){
    case 0: otoc(cas,rotrych); break;
    case 1: jdi(cas,posrych); break;
    case 2: otoc(cas,rotrych); break;
    case 3: jdi(cas,posrych); break;
    case 4: otoc(cas,rotrych); break;
    case 5: uchop(cas,P_J); break;
    case 6: jdi(cas,posrych); break;
    case 7: otoc(cas,rotrych); break;
    case 8: jdi(cas,posrych); break;
    case 9: otoc(cas,rotrych); break;
    
    case 10: uchop(cas,P_J); break;
    case 11: jdi(cas,posrych); break;
    case 12: otoc(cas,rotrych); break;
    case 13: jdi(cas,posrych); break;
    case 14: otoc(cas,rotrych); break;
    case 15: jdi(cas,posrych); break;
    case 16: uchop(cas,P_A);break;
    case 17: jdi(cas,posrych);break;
    case 18: otoc(cas,rotrych);break;
    case 19: jdi(cas,posrych);break;
    
    case 20: otoc(cas,rotrych);break;
    case 21: uchop(cas,P_A);break;
    case 22: otoc(cas,rotrych);break;
    case 23: jdi(cas,posrych);break;
    case 24: otoc(cas,rotrych);break;
    case 25: jdi(cas,posrych); break;
    case 26: otoc(cas,rotrych);break;
    case 27: uchop(cas,P_I);break;
    case 28: jdi(cas,posrych);break;
    case 29: otoc(cas,rotrych);break;
    
    case 30: jdi(cas,posrych);break;
    case 31: otoc(cas,rotrych);break;
    case 32: jdi(cas,posrych);break;
    case 33: uchop(cas,P_I);break;
    case 34: otoc(cas,rotrych);break;
    case 35: jdi(cas,posrych);break;
    case 36: otoc(cas,rotrych);break;
    case 37: jdi(cas,posrych);break;
    case 38: otoc(cas,rotrych);break;
    case 39: uchop(cas,P_E2);break;

    case 40: jdi(cas,posrych);break;    
    case 41: uchop(cas,P_E2); break;
    case 42: jdi(cas,posrych);break;
    case 43: otoc(cas,rotrych);break;
    case 44: jdi(cas,posrych);break;
    case 45: otoc(cas,rotrych);break;
    case 46: uchop(cas,P_R3);break;
    case 47: otoc(cas,rotrych);break;
    case 48: jdi(cas,posrych);break;
    case 49: otoc(cas,rotrych);break;
    
    case 50: uchop(cas,P_R3);break;
    case 51: otoc(cas,rotrych);break;
    case 52: jdi(cas,posrych);break;
    case 53: otoc(cas,rotrych);break;
    case 54: jdi(cas,posrych);break;
    case 55: otoc(cas,rotrych);break;
    case 56: uchop(cas,P_K2);break;
    case 57: otoc(cas,rotrych);break;
    case 58: jdi(cas,posrych);break;
    case 59: otoc(cas,rotrych);break;
    
    case 60: uchop(cas,P_K2);break;
    case 61: jdi(cas,posrych);break;
    case 62: otoc(cas,rotrych);break;
    case 63: jdi(cas,posrych);break;
    case 64: otoc(cas,rotrych);break;
    case 65: jdi(cas,posrych);break;
    case 66: uchop(cas,P_R);break;
    case 67: jdi(cas,posrych);break;
    case 68: otoc(cas,rotrych);break;
    case 69: jdi(cas,posrych);break;
    
    
    case 70: otoc(cas,rotrych);break;
    case 71: uchop(cas,P_R);break;
    case 72: otoc(cas,rotrych);break;
    case 73: jdi(cas,posrych);break;
    case 74: otoc(cas,rotrych);break;
    case 75: uchop(cas,P_K);break;
    case 76: otoc(cas,rotrych);break;
    case 77: jdi(cas,posrych);break;
    case 78: otoc(cas,rotrych);break;
    case 79: uchop(cas,P_K);break;
    
    case 80: otoc(cas,rotrych);break;
    case 81: jdi(cas,posrych);break;
    case 82: otoc(cas,rotrych);break;
    case 83: jdi(cas,posrych);break;
    case 84: otoc(cas,rotrych);break;
    case 85: uchop(cas,P_M);break;
    case 86: jdi(cas,posrych);break;
    case 87: otoc(cas,rotrych);break;
    case 88: jdi(cas,posrych);break;
    case 89: otoc(cas,rotrych);break;
    
    
    case 90: jdi(cas,posrych);break;
    case 91: uchop(cas,P_M);break;
    case 92: otoc(cas,rotrych);break;
    case 93: jdi(cas,posrych);break;
    case 94: otoc(cas,rotrych);break;
    case 95: jdi(cas,posrych);break;
    case 96: otoc(cas,rotrych);break;
    case 97: uchop(cas,P_E);break;
    case 98: otoc(cas,rotrych);break;
    case 99: jdi(cas,posrych);break;
    
    case 100: otoc(cas,rotrych);break;
    case 101: jdi(cas,posrych);break;
    case 102: uchop(cas,P_E);break;
    case 103: jdi(cas,posrych);break;
    case 104: otoc(cas,rotrych);break;
    case 105: jdi(cas,posrych);break;
    case 106: otoc(cas,rotrych);break;
    case 107: uchop(cas,P_S);break;
    case 108: jdi(cas,posrych);break;
    case 109: otoc(cas,rotrych);break;
    
    case 110: jdi(cas,posrych);break;
    case 111: otoc(cas,rotrych);break;
    case 112: jdi(cas,posrych);break;
    case 113: uchop(cas,P_S);break;
    case 114: jdi(cas,posrych);break;
    case 115: otoc(cas,rotrych);break;
    case 116: jdi(cas,posrych);break;
    case 117: otoc(cas,rotrych);break;
    case 118: uchop(cas,P_R2);break;
    case 119: otoc(cas,rotrych);break;
    
    case 120: jdi(cas,posrych);break;
    case 121: otoc(cas,rotrych);break;
    case 122: jdi(cas,posrych);break;
    case 123: uchop(cas,P_R2);break;
    case 124: vyjed(cas);break;
    
//    default: akce++; break;    
  }
}


//---------------------------------------------------------------------
// Pocatecni souradnice pismen
//---------------------------------------------------------------------
float pismeno[POCET_P+1][3]; //x, y a z sour.
void initpole(void){
//xxxxxxxxxxxxxxxxxxxx  yyyyyyyyyyyyyyyyyyyyy zzzzzzzzzzzzzzzzzzz
  pismeno[P_J][0]=15;   pismeno[P_J][1]=5;    pismeno[P_J][2]=0;
  pismeno[P_I][0]=-22;  pismeno[P_I][1]=-1.5; pismeno[P_I][2]=0;
  pismeno[P_R][0]=-45;  pismeno[P_R][1]=6;    pismeno[P_R][2]=0;
  pismeno[P_K][0]=4;    pismeno[P_K][1]=3;    pismeno[P_K][2]=0;
  pismeno[P_A][0]=-24;  pismeno[P_A][1]=6;    pismeno[P_A][2]=0;
  pismeno[P_K2][0]=22;  pismeno[P_K2][1]=3;   pismeno[P_K2][2]=0;
  pismeno[P_R2][0]=-13; pismeno[P_R2][1]=6;   pismeno[P_R2][2]=0;
  pismeno[P_E][0]=26;   pismeno[P_E][1]=2;    pismeno[P_E][2]=0;
  pismeno[P_M][0]=30;   pismeno[P_M][1]=0;    pismeno[P_M][2]=0;
  pismeno[P_S][0]=39;   pismeno[P_S][1]=5;    pismeno[P_S][2]=0;
  pismeno[P_E2][0]=47;  pismeno[P_E2][1]=2;   pismeno[P_E2][2]=0;
  pismeno[P_R3][0]=21;  pismeno[P_R3][1]=6;   pismeno[P_R3][2]=0;
  pismeno[P_I2][0]=38;  pismeno[P_I2][1]=9.5;pismeno[P_I2][2]=44.3;
//xxxxxxxxxxxxxxxxxxxx  yyyyyyyyyyyyyyyyyyyyy zzzzzzzzzzzzzzzzzzz
  return;
}


//---------------------------------------------------------------------
// "Vyjeti icka"
//---------------------------------------------------------------------

void vyjed(int cas){
  if (cas){              
    pismeno[P_I2][1]-=0.2;                    
    glutPostRedisplay();
    glutTimerFunc( 75, animuj, cas-1);  
  }  
}


//---------------------------------------------------------------------
// Toceni robota
//---------------------------------------------------------------------
void otoc(int okolik,int rychlost){
  if (okolik){
    if (Rrotace==0)Rrotace=359;  
    if (Rrotace==360)Rrotace=0;            
    Rrotace+=1*((okolik>0)?1:-1);
    glutPostRedisplay();
    glutTimerFunc( rychlost, animuj, okolik+1*((okolik<0)?1:-1));  
  }
}

//---------------------------------------------------------------------
// Chuze robotova
//---------------------------------------------------------------------
int leva=1;
void jdi(int kolik,int rychlost){
  if (kolik){
    if ((Rrotace>=0)&&(Rrotace<=90)){
      pom = Rrotace/180.0;
      if (kolik>0){
        Rx+=pom;
        Rz+=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]+=pom;;
          pismeno[pisvruce][2]+=0.5-pom;
        }
      }
      else {
        Rx-=pom;
        Rz-=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]-=pom;;
          pismeno[pisvruce][2]-=0.5-pom;
        }
      }
    }  
    else if ((Rrotace>90)&&(Rrotace<=180)){
      pom = (180-Rrotace)/180.0;
      if (kolik>0){
        Rx+=pom;
        Rz-=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]+=pom;;
          pismeno[pisvruce][2]-=0.5-pom;
        }
      }
      else {
        Rx-=pom;
        Rz+=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]-=pom;;
          pismeno[pisvruce][2]+=0.5-pom;
        }
      }
    }  
    else if ((Rrotace>180)&&(Rrotace<=270)){
      pom = (Rrotace-180)/180.0;
      if (kolik>0){
        Rx-=pom;
        Rz-=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]-=pom;;
          pismeno[pisvruce][2]-=0.5-pom;
        }
      }
      else {
        Rx+=pom;
        Rz+=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]+=pom;;
          pismeno[pisvruce][2]+=0.5-pom;
        }
      }
    }  
    else if ((Rrotace>270)&&(Rrotace<360)){
      pom = (360-Rrotace)/180.0;
      if (kolik>0){
        Rx-=pom;
        Rz+=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]-=pom;;
          pismeno[pisvruce][2]+=0.5-pom;
        }
      }  
      else {
        Rx+=pom;
        Rz-=0.5-pom;
        if(pisvruce){
          pismeno[pisvruce][0]+=pom;;
          pismeno[pisvruce][2]-=0.5-pom;
        }
      }
    }
    if (leva){ 
      rotnoha++;
      if (rotnoha>=10) leva=0;
    }
    else {
      rotnoha--;
      if (rotnoha<=-10) leva=1;
    }
    glutPostRedisplay();
    glutTimerFunc( rychlost, animuj, kolik+1*((kolik<0)?1:-1)); 
  }
}

//---------------------------------------------------------------------
// Uchopi/odchopi pismeno
//---------------------------------------------------------------------
void uchop(int okolik,int pismeno){
  if(okolik){
    if(okolik<0){
      rotruka--;
      pisvruce=0; //pusti pismeno
    }
    else {
      rotruka++;
      pisvruce=pismeno;
    }
    glutPostRedisplay();
    glutTimerFunc( 2, animuj, okolik+1*((okolik<0)?1:-1));     
  }
}















//---------------------------------------------------------------------
// Funkce pro inicializaci vykreslovani
//---------------------------------------------------------------------
void onInit(void){
    loadTextures();
    glClearColor(0.0f, 0.1f, 0.2f, 0.0f);       // barva pozadi obrazku
    glClearDepth(1.0f);                         // implicitni hloubka ulozena v pameti hloubky
    glEnable(GL_DEPTH_TEST);                    // povoleni funkce pro testovani hodnot v pameti hloubky
    glEnable(GL_NORMALIZE);                     // Je vypo�tena d�lka norm�lov�ho vektoru
    glDepthFunc(GL_LESS);                       // funkce pro testovani fragmentu
    glShadeModel(GL_SMOOTH);                    // nastaveni stinovaciho rezimu
    glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);// vylepseni zobrazovani textur
    glPolygonMode(GL_FRONT_AND_BACK,cary);       // nastaveni vykresleni vyplnenych polygonu    
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    
    glEnable(GL_FOG);
    glFogi(GL_FOG_MODE, fogMode);
    glFogfv(GL_FOG_COLOR, fogColor);
    glFogf(GL_FOG_DENSITY, fogDensity);// hustota mlhy
    glHint(GL_FOG_HINT, GL_DONT_CARE);
    glFogf(GL_FOG_START, 7.0);
    glFogf(GL_FOG_END, 5.0);
    initpole(); // souradnice pismen
    makeLists();
//    glutSetCursor(GLUT_CURSOR_HAND);
}  















//---------------------------------------------------------------------
// Nacteni bitmapy ze souboru typu BMP
//---------------------------------------------------------------------
int bitmapLoad(int texture, const char *filename){
    FILE          *fin;
    int           width, height, bpp=0;
    int           size;
    unsigned char *bitmap;
    unsigned char bmpHeader[54]={0x42, 0x4d,        // magicke cislo souboru BMP
                        0x00, 0x00, 0x00, 0x00,     // velikost souboru
                        0x00, 0x00, 0x00, 0x00,     // rezervovano, vzdy nastaveno na nula
                        0x36, 0x04, 0x00, 0x00,     // data offset=54
                        0x28, 0x00, 0x00, 0x00,     // velikost hlavicky=40
                        0x00, 0x00, 0x00, 0x00,     // sirka obrazku v pixelech=?
                        0x00, 0x00, 0x00, 0x00,     // vyska obrazku v pixelech=?
                        0x01, 0x00,                 // pocet bitovych rovin=1
                        0x08, 0x00,                 // pocet bitu na pixel=24
                        0x00, 0x00, 0x00, 0x00,     // metoda komprimace=nic
                        0x00, 0x00, 0x00, 0x00,     // velikost bitmapy
                        0x00, 0x00, 0x00, 0x00,     // pocet pixelu na metr v horizontalnim smeru
                        0x00, 0x00, 0x00, 0x00,     // pocet pixelu na metr ve vertikalnim smeru
                        0x00, 0x00, 0x00, 0x00,     // pocet pouzitych barev
                        0x00, 0x00, 0x00, 0x00,     // pocet dulezitych barev
    };
    if (!filename) return -1;
    fin=fopen(filename, "rb");
    if (!fin) return -1;                            // otevreni souboru se nezdarilo
    if (fread(bmpHeader, 54, 1, fin)!=1) return -1; // nacist hlavicku BMP souboru
    memcpy(&width, bmpHeader+18, 4);                // sirka obrazku v pixelech
    memcpy(&height, bmpHeader+22, 4);               // vyska obrazku v pixelech
    memcpy(&bpp, bmpHeader+28, 2);                  // pocet bitu na pixel
    if (bpp!=24) return -1;
    size=width*height*3;
    bitmap=(unsigned char *)malloc(size*sizeof(unsigned char));
    if (fread(bitmap, size, sizeof(unsigned char), fin)!=1) return -1;// nacteni rastrovych dat
    fclose(fin);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // opakovani textury
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height,0, GL_RGB, GL_UNSIGNED_BYTE, bitmap);
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, bitmap);
                 
    free(bitmap);
    return 0;
}



//---------------------------------------------------------------------
// Nastaveni souradneho systemu v zavislosti na velikosti okna
//---------------------------------------------------------------------
void onResize(int w, int h){                    // argumenty w a h reprezentuji novou velikost okna
    glViewport(0, 0, w, h);                     // viditelna oblast pres cele okno
    windowWidth=w;                              // zapamatovat si velikost okna
    windowHeight=h;
  return;
}




//---------------------------------------------------------------------
// Nastaveni perspektivni projekce
//---------------------------------------------------------------------
void setPerspectiveProjection(void){
    glMatrixMode(GL_PROJECTION);                // zacatek modifikace projekcni matice
    glLoadIdentity();                           // vymazani projekcni matice (=identita)
    gluPerspective(70.0, (double)windowWidth/(double)windowHeight, 0.1f, 900.0f);// nastaveni perspektivni kamery
    glMatrixMode(GL_MODELVIEW);                 // bude se menit modelova matice
    glLoadIdentity();                           // nahrat jednotkovou matici
}



//--------------------------------------------------------------------
// Vykresleni robota
//--------------------------------------------------------------------
void drawRobot(void){
int pis;
    glMaterialfv(GL_FRONT, GL_AMBIENT, robotAmbient);    // nastaveni ambientni slozky barvy materialu
    glMaterialfv(GL_FRONT, GL_DIFFUSE, robotDiffuse);    // nastaveni difuzni slozky barvy materialu
    glMaterialfv(GL_FRONT, GL_SPECULAR, robotSpecular);  // nastaveni barvy odlesku
    glMaterialfv(GL_FRONT, GL_SHININESS, robotShininess);// nastaveni faktoru odlesku

glPushMatrix();
  glTranslatef(Rx,-5,Rz);
  glRotatef(Rrotace,0,1,0); //celkove natoceni robota
  glScalef(0.4,0.4,0.4);
  glCallList(R_HLAVA);
  glMaterialfv(GL_FRONT, GL_AMBIENT, belmoAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, belmoDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, belmoSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, belmoShininess);
  glColor3f(1.0f, 1.0f, 1.0f);
  glCallList(R_OKO);
  glMaterialfv(GL_FRONT, GL_AMBIENT, zorAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, zorDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, zorSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, zorShininess);
  glColor3f(0.0f, 0.0f, 0.0f);
  glCallList(R_ZOR);
  
  glPushMatrix();
    glTranslatef(-1.33,0,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT, belmoAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, belmoDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, belmoSpecular);
    glMaterialfv(GL_FRONT, GL_SHININESS, belmoShininess);
    glColor3f(1.0f, 1.0f, 1.0f);
    glCallList(R_OKO);
    glMaterialfv(GL_FRONT, GL_AMBIENT, zorAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, zorDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, zorSpecular);
    glMaterialfv(GL_FRONT, GL_SHININESS, zorShininess);
    glColor3f(0.0f, 0.0f, 0.0f);
    glCallList(R_ZOR);
  glPopMatrix();
  
  glMaterialfv(GL_FRONT, GL_AMBIENT, belmoAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, belmoDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, belmoSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, belmoShininess);
  glColor3f(1.0f, 1.0f, 1.0f);
  glCallList(R_ZUBY);
  
  glMaterialfv(GL_FRONT, GL_AMBIENT, robotAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, robotDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, robotSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, robotShininess);
  glColor3f(0.0f, 0.2f, 0.4f);
  glCallList(R_TRUP);
  
  glPushMatrix();
    glTranslatef(1.3,0,0);
    glRotatef(-rotruka,0,1,0);
    glTranslatef(-1.3,0,0);
    glCallList(R_RUKA);
  glPopMatrix();
  
  if(pisvruce){            
  glMaterialfv(GL_FRONT, GL_AMBIENT, pisAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, pisDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, pisSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, pisShininess);
    glPushMatrix();
      glScalef(2.5,2.5,2.5);
      glTranslatef(-Rx+pismeno[pisvruce][0]+0.1,-pismeno[pisvruce][1]-15,68.45-pismeno[pisvruce][2]+Rz); // z = -20, y = 5, x = 50
      switch (pisvruce){
        case 6: pis=4; break;
        case 12: case 7: pis=3; break;
        case 11: pis=8; break;
        default: pis=pisvruce; break;
      }
      glRotatef(90,1,0,0);
      glCallList(pis);
    glPopMatrix();
  glMaterialfv(GL_FRONT, GL_AMBIENT, robotAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, robotDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, robotSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, robotShininess);  
  }

  glPushMatrix();
    glTranslatef(0,7,0);
    glRotatef(-rotnoha*2,1,0,0);
    glTranslatef(0,-7,0);
    glCallList(R_NOHA);
  glPopMatrix();
  
  glPushMatrix();
   glTranslatef(3,7,0);
    glRotatef(rotnoha*2,1,0,0);
    glTranslatef(0,-7,0);
    glCallList(R_NOHA);
  glPopMatrix();
    
  glPushMatrix();
    glScalef(-1,1,1);
    glTranslatef(1.3,0,0);
    glRotatef(-rotruka,0,1,0);
    glTranslatef(-1.3,0,0);
    glCallList(R_RUKA);
  glPopMatrix();  
  
glPopMatrix();
return;
}
  
  
//--------------------------------------------------------------------
// Vykresleni pismena
//--------------------------------------------------------------------
void drawScene(void){  

  glPushMatrix();
  glTranslatef(0,-20,-60);  
  glRotatef(90,1,0,0);
  
  glMaterialfv(GL_FRONT, GL_AMBIENT, pisAmbient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, pisDiffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, pisSpecular);
  glMaterialfv(GL_FRONT, GL_SHININESS, pisShininess);
  
  for (int i=1;i<=POCET_P;i++){
    int pis;
    if(pisvruce!=i){
      glPushMatrix();  
        //x z y 
        glTranslatef(pismeno[i][0],pismeno[i][2],pismeno[i][1]);                 
        switch (i){
          case 6: pis=4; break;
          case 12: case 7: pis=3; break;
          case 11: pis=8; break;
          case 13: pis=2; break;
          default: pis=i; break;
        }
        glCallList(pis);
      glPopMatrix();
    }       
  }
  glPopMatrix();
  return;
}


//--------------------------------------------------------------------
// Vykresleni povrchu
//--------------------------------------------------------------------
void drawGround(void){
  glutSolidSphere(500, 100, 100);     
  
if(textury) glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, textures[1]);   // navazani textury
    
    glBegin(GL_QUADS);
      glTexCoord2f(100, 0.0);
      glVertex3f(-1000, -5, -1000);   
      glTexCoord2f(100, 100);
      glVertex3f(1000,-5, -1000);
      glTexCoord2f(0.0, 100);
      glVertex3f(1000, -5, 1000);
      glTexCoord2f(0.0, 0.0);
      glVertex3f(-1000, -5, 1000);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}


//--------------------------------------------------------------------
// Tato funkce je volana pri kazdem prekresleni okna
//--------------------------------------------------------------------
void onDisplay(void){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);// vymazani barvoveho bufferu i pameti hloubky
    setPerspectiveProjection();                 // nastaveni perspektivni kamery

    glTranslatef(0.0f, -10.0f, znew-60.0f);           // posun objektu dale od kamery
    glRotatef(ynew, 1.0f, 0.0f, 0.0f);
    glRotatef(xnew, 0.0f, 1.0f, 0.0f);
        
    glColor3f(0.0f, 0.4f, 0.2f);
    drawGround();
    glColor3f(0.0f, 0.2f, 0.4f);
    drawRobot();                                // objekt vykresleny se zapnutou mlhou
    glColor3f(0.0f, 0.2f, 0.0f);
    drawScene();
    glFlush();                                  // provedeni a vykresleni vsech zmen
    glutSwapBuffers();                          // a prohozeni predniho a zadniho bufferu
    return;
}


//---------------------------------------------------------------------
// Callback funkce zavolana pri stlaceni non-ASCII klavesy
//---------------------------------------------------------------------
void onKeySpecial(int key, int x, int y){
    switch (key) {
        case GLUT_KEY_UP:
            break;
        case GLUT_KEY_DOWN:
            break;
        case GLUT_KEY_LEFT:
            break;
        case GLUT_KEY_RIGHT:
            break;
        default: break;
    }
    glutPostRedisplay();
  return;
}


//---------------------------------------------------------------------
// Tato funkce je volana pri stlaceni ASCII klavesy
//---------------------------------------------------------------------
void onKeyboard(unsigned char key, int x, int y){
    if (key>='A' && key<='Z')                   // uprava velkych pismen na mala
        key+='a'-'A';                           // pro zjednoduseni prikazu switch

    switch (key) {
        case 27:    exit(0);            break;  // ukonceni aplikace
        case 'q':   exit(0);            break;  // ukonceni aplikace
        case 'f':   glutFullScreen();   break; 
        case 's': 
          if (svetlo) glDisable(GL_LIGHTING);
          else glEnable(GL_LIGHTING);
          svetlo=(!svetlo);
        break;
        case 'm': 
          if (mlha) glDisable(GL_FOG);
          else glEnable(GL_FOG);
          mlha=(!mlha);
        break;
        case 't': 
          if (textury) glDisable(GL_TEXTURE);
          else glEnable(GL_TEXTURE);
          textury=(!textury);
        break;
        case 'p': 
          if (cary==GL_FILL) cary=GL_LINE;
          else cary=GL_FILL;
          glPolygonMode(GL_FRONT_AND_BACK,cary);
        break;
        default:                        break;
    }
  return;
}


//---------------------------------------------------------------------
// Tato funkce je volana pri stisku ci pusteni tlacitka mysi
//---------------------------------------------------------------------
void onMouseButton(int button, int state, int x, int y){
    if (button==GLUT_LEFT_BUTTON) {             // pri zmene stavu leveho tlacitka
        operation=ROTATE;
        if (state==GLUT_DOWN) {                 // pri stlaceni tlacitka
            xx=x;                               // zapamatovat pozici kurzoru mysi
            yy=y;
        }
        else {                                  // pri pusteni tlacitka
            xold=xnew;                          // zapamatovat novy pocatek
            yold=ynew;
        }
        glutPostRedisplay();                    // prekresleni sceny
    }
    if (button==GLUT_RIGHT_BUTTON) {
        operation=TRANSLATE;
        if (state==GLUT_DOWN) zz=y;             // pri stlaceni tlacitka zapamatovat polohu kurzoru mysi
        else zold=znew;                         // pri pusteni tlacitka zapamatovat novy pocatek
        glutPostRedisplay();                    // prekresleni sceny
    }
  return;
}


//---------------------------------------------------------------------
// Tato funkce je volana pri pohybu mysi se stlacenym tlacitkem.
// To, ktere tlacitko je stlaceno si musime predem zaznamenat do
// globalni promenne stav ve funkci onMouseButton()
//---------------------------------------------------------------------
void onMouseMotion(int x, int y){
         switch (operation) {
        case ROTATE:                            // stav rotace objektu
            xnew=xold+x-xx;                     // vypocitat novou pozici
            ynew=yold+y-yy;
            glutPostRedisplay();                // a prekreslit scenu
            break;
        case TRANSLATE:                         // stav priblizeni/oddaleni objektu
            znew=zold+y-zz;                     // vypocitat novou pozici
            glutPostRedisplay();                // a prekreslit scenu
            break;
    }
}


//---------------------------------------------------------------------
// Hlavni funkce konzolove aplikace
//---------------------------------------------------------------------
int main(int argc, char **argv){

    glutInit(&argc, argv);                      // inicializace knihovny GLUT
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);// nastaveni dvou barvovych bufferu a pameti hloubky
    glutInitWindowPosition(30, 30);             // pocatecni pozice leveho horniho rohu okna
    glutInitWindowSize(500, 500);               // pocatecni velikost okna
    glutCreateWindow("Mega rychly robot");      // vytvoreni okna pro kresleni
    glutDisplayFunc(onDisplay);                 // registrace funkce volane pri prekreslovani okna
    glutReshapeFunc(onResize);                  // registrace funkce volane pri zmene velikosti okna
    glutKeyboardFunc(onKeyboard);               // registrace funkce volane pri stlaceni klavesy
    glutSpecialFunc(onKeySpecial);              // registrace funkce volane pri stisku non-ASCII klavesy
    glutMouseFunc(onMouseButton);               // registrace funkce volane pri stlaceni ci pusteni tlacitka
    glutMotionFunc(onMouseMotion);              // registrace funkce volane pri pohybu mysi se stlacenym tlacitkem
    onInit();                                   // inicializace vykreslovani
    glutTimerFunc(40,animuj,casy[0]);           // registrace casovace obsluhujici animaci
    glutMainLoop();                             // nekonecna smycka, kde se volaji zaregistrovane funkce
    return 0;                                   // navratova hodnota vracena operacnimu systemu
}



//                                                           ---------
//                                                           | Konec |
//                                                           ---------
